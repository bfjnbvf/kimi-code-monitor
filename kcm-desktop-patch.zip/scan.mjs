#!/usr/bin/env node

// src/panel-app/patch/scan.mjs
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { StringDecoder } from "node:string_decoder";
import { pathToFileURL } from "node:url";

// src/metrics.js
function toNonNegativeInteger(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? Math.floor(number) : 0;
}
function firstDefined(source, keys) {
  for (const key of keys) {
    if ((source == null ? void 0 : source[key]) != null) return source[key];
  }
  return 0;
}
function normalizeUsage(raw) {
  const usage = raw && typeof raw === "object" ? raw : {};
  return {
    inputTokens: toNonNegativeInteger(firstDefined(usage, [
      "inputOther",
      "input_tokens",
      "prompt_tokens"
    ])),
    outputTokens: toNonNegativeInteger(firstDefined(usage, [
      "output",
      "output_tokens",
      "completion_tokens"
    ])),
    cacheReadTokens: toNonNegativeInteger(firstDefined(usage, [
      "inputCacheRead",
      "cache_read_input_tokens",
      "cache_read_tokens"
    ])),
    cacheCreationTokens: toNonNegativeInteger(firstDefined(usage, [
      "inputCacheCreation",
      "cache_creation_input_tokens",
      "cache_creation_tokens"
    ]))
  };
}
function totalInputTokens(usage) {
  return usage.inputTokens + usage.cacheReadTokens + usage.cacheCreationTokens;
}
function usageDayKey(date = /* @__PURE__ */ new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
function usageHourKey(date = /* @__PURE__ */ new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return `${usageDayKey(d)}T${String(d.getHours()).padStart(2, "0")}`;
}
function pruneHourlyUsage(hourly, keepDays = 2, now = /* @__PURE__ */ new Date()) {
  const cutoff = new Date(now);
  cutoff.setDate(cutoff.getDate() - (keepDays - 1));
  const cutoffKey = `${usageDayKey(cutoff)}T00`;
  const next = {};
  for (const [key, bucket] of Object.entries(hourly || {})) {
    if (key >= cutoffKey) next[key] = bucket;
  }
  return next;
}
function pruneDailyUsage(daily, keepDays = 90, now = /* @__PURE__ */ new Date()) {
  const cutoff = new Date(now);
  cutoff.setDate(cutoff.getDate() - (keepDays - 1));
  const cutoffKey = usageDayKey(cutoff);
  const next = {};
  for (const [key, bucket] of Object.entries(daily || {})) {
    if (key >= cutoffKey) next[key] = bucket;
  }
  return next;
}

// src/cli-usage.js
var READ_CHUNK_BYTES = 1024 * 1024;
function emptyBucket() {
  return { input: 0, output: 0, cacheRead: 0 };
}
function addUsageRecord(daily, record, isSubagent = false, meta = null) {
  if ((record == null ? void 0 : record.type) !== "usage.record" || !record.usage) return false;
  const time = Number(record.time);
  if (!Number.isFinite(time)) return false;
  const usage = normalizeUsage(record.usage);
  const key = usageDayKey(new Date(time));
  const bucket = { ...emptyBucket(), ...daily[key] || {} };
  const input = totalInputTokens(usage);
  bucket.input += input;
  bucket.output += usage.outputTokens;
  bucket.cacheRead += usage.cacheReadTokens;
  if (isSubagent) {
    const sub = { input: 0, output: 0, cacheRead: 0, ...bucket.sub || {} };
    sub.input += input;
    sub.output += usage.outputTokens;
    sub.cacheRead += usage.cacheReadTokens;
    bucket.sub = sub;
  }
  daily[key] = bucket;
  if (meta) {
    const total = input + usage.outputTokens;
    const model = typeof record.model === "string" && record.model ? record.model : "unknown";
    meta.models[model] = (meta.models[model] || 0) + total;
    if (meta.firstAt == null || time < meta.firstAt) meta.firstAt = time;
    if (meta.lastAt == null || time > meta.lastAt) meta.lastAt = time;
  }
  return true;
}
function addHourlyRecord(hourly, record, isSubagent = false) {
  const time = Number(record == null ? void 0 : record.time);
  if (!Number.isFinite(time) || !record.usage) return;
  const usage = normalizeUsage(record.usage);
  const key = usageHourKey(new Date(time));
  const bucket = { ...emptyBucket(), ...hourly[key] || {} };
  const input = totalInputTokens(usage);
  bucket.input += input;
  bucket.output += usage.outputTokens;
  bucket.cacheRead += usage.cacheReadTokens;
  if (isSubagent) {
    const sub = { input: 0, output: 0, cacheRead: 0, ...bucket.sub || {} };
    sub.input += input;
    sub.output += usage.outputTokens;
    sub.cacheRead += usage.cacheReadTokens;
    bucket.sub = sub;
  }
  hourly[key] = bucket;
}
function parseUsageLines(text, daily, hourly = null, isSubagent = false, meta = null) {
  var _a;
  let count = 0;
  for (const line of String(text || "").split("\n")) {
    if (line.includes('"usage.record"')) {
      try {
        const parsed = JSON.parse(line);
        if (addUsageRecord(daily, parsed, isSubagent, meta)) {
          count += 1;
          if (hourly) addHourlyRecord(hourly, parsed, isSubagent);
        }
      } catch (error) {
      }
    } else if (meta && line.includes('"config.update"') && line.includes('"modelAlias"')) {
      try {
        const alias = (_a = JSON.parse(line)) == null ? void 0 : _a.modelAlias;
        if (typeof alias === "string" && alias) meta.modelAlias = alias;
      } catch (error) {
      }
    }
  }
  return count;
}

// src/panel-app/patch/scan.mjs
var READ_CHUNK_BYTES2 = 4 * 1024 * 1024;
function listWireFiles(sessionsDir) {
  const files = [];
  let workspaces;
  try {
    workspaces = fs.readdirSync(sessionsDir, { withFileTypes: true });
  } catch (error) {
    return files;
  }
  for (const workspace of workspaces) {
    if (!workspace.isDirectory()) continue;
    const workspaceDir = path.join(sessionsDir, workspace.name);
    let sessions;
    try {
      sessions = fs.readdirSync(workspaceDir, { withFileTypes: true });
    } catch (error) {
      continue;
    }
    for (const session of sessions) {
      if (!session.isDirectory() || !session.name.startsWith("session_")) continue;
      const agentsDir = path.join(workspaceDir, session.name, "agents");
      let agents;
      try {
        agents = fs.readdirSync(agentsDir, { withFileTypes: true });
      } catch (error) {
        continue;
      }
      for (const agent of agents) {
        if (!agent.isDirectory()) continue;
        const wire = path.join(agentsDir, agent.name, "wire.jsonl");
        if (!fs.existsSync(wire)) continue;
        files.push({
          // agents/main 为主代理，其余（agent-N 等）按子代理分桶
          path: wire,
          isSubagent: agent.name !== "main"
        });
      }
    }
  }
  return files;
}
function scanFileStream(filePath, daily, hourly, isSubagent) {
  const decoder = new StringDecoder("utf8");
  let carry = "";
  let records = 0;
  const buffer = Buffer.alloc(READ_CHUNK_BYTES2);
  const fd = fs.openSync(filePath, "r");
  try {
    let read;
    while ((read = fs.readSync(fd, buffer, 0, READ_CHUNK_BYTES2, null)) > 0) {
      const text = carry + decoder.write(buffer.subarray(0, read));
      const lastNewline = text.lastIndexOf("\n");
      if (lastNewline < 0) {
        carry = text;
        continue;
      }
      carry = text.slice(lastNewline + 1);
      records += parseUsageLines(text.slice(0, lastNewline + 1), daily, hourly, isSubagent);
    }
    const tail = carry + decoder.end();
    if (tail.includes("\n")) {
      records += parseUsageLines(tail.slice(0, tail.lastIndexOf("\n") + 1), daily, hourly, isSubagent);
    }
  } finally {
    fs.closeSync(fd);
  }
  return records;
}
function readSecondaryModel(kimiHome) {
  try {
    const text = fs.readFileSync(path.join(kimiHome, "config.toml"), "utf8");
    const match = text.match(/\[secondary_model\][\s\S]*?model\s*=\s*"([^"]+)"/);
    return match ? match[1] : "";
  } catch (error) {
    return "";
  }
}
function scanSessions(sessionsDir) {
  const daily = {};
  const hourly = {};
  const failures = [];
  const files = listWireFiles(sessionsDir);
  let recordCount = 0;
  for (const entry of files) {
    try {
      recordCount += scanFileStream(entry.path, daily, hourly, entry.isSubagent);
    } catch (error) {
      failures.push(`${entry.path}: ${(error == null ? void 0 : error.message) || error}`);
    }
  }
  return {
    daily: pruneDailyUsage(daily),
    hourly: pruneHourlyUsage(hourly),
    secondaryModel: readSecondaryModel(path.dirname(path.resolve(sessionsDir))),
    fileCount: files.length,
    recordCount,
    failures
  };
}
function renderUsageDailyJs(data) {
  const payload = {
    daily: data.daily || {},
    hourly: data.hourly || {},
    secondaryModel: typeof data.secondaryModel === "string" ? data.secondaryModel : ""
  };
  return `window.__kcmUsageDaily = ${JSON.stringify(payload)};
`;
}
function parseArgs(argv) {
  const args = { sessions: path.join(os.homedir(), ".kimi-code", "sessions"), out: "", stdout: false };
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--sessions") args.sessions = argv[i += 1];
    else if (argv[i] === "--out") args.out = argv[i += 1];
    else if (argv[i] === "--stdout") args.stdout = true;
  }
  return args;
}
function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.stdout && !args.out) {
    console.error("\u7528\u6CD5: node scan.mjs --sessions <dir> --out <file> | --stdout");
    process.exit(1);
  }
  if (!fs.existsSync(args.sessions)) {
    console.error(`[scan] sessions \u76EE\u5F55\u4E0D\u5B58\u5728\uFF1A${args.sessions}\uFF08\u5168\u65B0\u73AF\u5883\uFF1F\u65E0\u5386\u53F2\u53EF\u9884\u586B\uFF09`);
    process.exit(2);
  }
  const startedAt = Date.now();
  const result = scanSessions(args.sessions);
  const js = renderUsageDailyJs(result);
  if (args.stdout) {
    process.stdout.write(js);
  } else {
    fs.mkdirSync(path.dirname(args.out), { recursive: true });
    fs.writeFileSync(args.out, js);
  }
  const days = Object.keys(result.daily).sort();
  console.error(
    `[scan] \u6587\u4EF6 ${result.fileCount} \xB7 \u8BB0\u5F55 ${result.recordCount} \xB7 \u5929\u6570 ${days.length}` + (days.length ? `\uFF08${days[0]} ~ ${days[days.length - 1]}\uFF09` : "") + ` \xB7 \u8017\u65F6 ${((Date.now() - startedAt) / 1e3).toFixed(1)}s` + (result.failures.length ? ` \xB7 \u5931\u8D25\u6587\u4EF6 ${result.failures.length}\uFF08\u5DF2\u8DF3\u8FC7\uFF09` : "")
  );
  for (const failure of result.failures.slice(0, 5)) console.error(`[scan]   ${failure}`);
}
if (process.argv[1] && import.meta.url === pathToFileURL(fs.realpathSync(process.argv[1])).href) {
  main();
}
export {
  listWireFiles,
  renderUsageDailyJs,
  scanSessions
};
