(() => {
  // src/panel-app/shims.js
  var RUNTIME_ID = "kcm-panel";
  var memoryStore = /* @__PURE__ */ new Map();
  var localStorageWorks = true;
  try {
    const probe = "__ksb_probe__";
    localStorage.setItem(probe, "1");
    localStorage.removeItem(probe);
  } catch (error) {
    localStorageWorks = false;
  }
  function storageRead(key) {
    try {
      if (localStorageWorks) {
        const raw = localStorage.getItem(key);
        return raw === null ? void 0 : JSON.parse(raw);
      }
    } catch (error) {
    }
    return memoryStore.has(key) ? memoryStore.get(key) : void 0;
  }
  function storageWrite(key, value) {
    try {
      if (localStorageWorks) {
        localStorage.setItem(key, JSON.stringify(value));
        return;
      }
    } catch (error) {
    }
    memoryStore.set(key, value);
  }
  function storageDelete(key) {
    if (localStorageWorks) {
      try {
        localStorage.removeItem(key);
      } catch (error) {
      }
    }
    memoryStore.delete(key);
  }
  function storageLocalGet(keys) {
    return new Promise((resolve) => {
      const want = keys == null ? [] : Array.isArray(keys) ? keys : typeof keys === "object" ? Object.keys(keys) : [keys];
      const result = {};
      if (keys == null) {
        if (localStorageWorks) {
          try {
            for (let i = 0; i < localStorage.length; i += 1) {
              const key = localStorage.key(i);
              const value = storageRead(key);
              if (value !== void 0) result[key] = value;
            }
          } catch (error) {
          }
        }
        for (const [key, value] of memoryStore) result[key] = value;
        resolve(result);
        return;
      }
      for (const key of want) {
        const value = storageRead(key);
        if (value !== void 0) result[key] = value;
      }
      resolve(result);
    });
  }
  function storageLocalSet(items) {
    return new Promise((resolve) => {
      for (const [key, value] of Object.entries(items || {})) storageWrite(key, value);
      resolve();
    });
  }
  function storageLocalRemove(keys) {
    return new Promise((resolve) => {
      const list = Array.isArray(keys) ? keys : keys == null ? [] : [keys];
      for (const key of list) storageDelete(key);
      resolve();
    });
  }
  var noopListenerHub = {
    addListener() {
    },
    removeListener() {
    },
    hasListener: () => false
  };
  function resolveResourcePath(path) {
    const rel = String(path || "").replace(/^chrome-extension:\/\/[^/]+\//, "");
    const assets = globalThis.__kcmAssets;
    if (assets && typeof assets === "object" && typeof assets[rel] === "string") {
      return assets[rel];
    }
    return rel;
  }
  function sendMessage() {
    return Promise.resolve(void 0);
  }
  globalThis.chrome = {
    runtime: {
      id: RUNTIME_ID,
      getURL: resolveResourcePath,
      sendMessage,
      onMessage: noopListenerHub,
      onConnect: noopListenerHub,
      // 面板页不打开扩展自有页面，留 no-op 桩
      openOptionsPage: () => Promise.resolve()
    },
    storage: {
      local: {
        get: storageLocalGet,
        set: storageLocalSet,
        remove: storageLocalRemove,
        clear: () => storageLocalRemove(null)
      },
      onChanged: noopListenerHub
    }
  };

  // src/metrics.js
  var MIN_SPEED_DURATION_MS = 100;
  function toNonNegativeInteger(value) {
    const number = Number(value);
    return Number.isFinite(number) && number > 0 ? Math.floor(number) : 0;
  }
  function firstDefined(source, keys) {
    for (const key of keys) {
      if (source?.[key] != null) return source[key];
    }
    return 0;
  }
  function normalizeUsage(raw) {
    const usage = raw && typeof raw === "object" ? raw : {};
    return {
      inputTokens: toNonNegativeInteger(firstDefined(usage, [
        "inputOther",
        "input_tokens",
        "prompt_tokens"
      ])),
      outputTokens: toNonNegativeInteger(firstDefined(usage, [
        "output",
        "output_tokens",
        "completion_tokens"
      ])),
      cacheReadTokens: toNonNegativeInteger(firstDefined(usage, [
        "inputCacheRead",
        "cache_read_input_tokens",
        "cache_read_tokens"
      ])),
      cacheCreationTokens: toNonNegativeInteger(firstDefined(usage, [
        "inputCacheCreation",
        "cache_creation_input_tokens",
        "cache_creation_tokens"
      ]))
    };
  }
  function totalInputTokens(usage) {
    return usage.inputTokens + usage.cacheReadTokens + usage.cacheCreationTokens;
  }
  function cacheReadPercentage(usage) {
    const total = totalInputTokens(usage);
    return total > 0 ? usage.cacheReadTokens / total * 100 : null;
  }
  function formatPercentage(value, decimals = 1) {
    if (value == null || value === "") return null;
    const number = Number(value);
    if (!Number.isFinite(number)) return null;
    const places = Math.max(0, Math.min(6, Math.floor(Number(decimals) || 0)));
    const factor = 10 ** places;
    const clamped = Math.max(0, Math.min(100, number));
    const truncated = Math.floor(clamped * factor + 1e-6) / factor;
    return truncated.toFixed(places);
  }
  function usageDayKey(date = /* @__PURE__ */ new Date()) {
    const d = date instanceof Date ? date : new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }
  function usageHourKey(date = /* @__PURE__ */ new Date()) {
    const d = date instanceof Date ? date : new Date(date);
    return `${usageDayKey(d)}T${String(d.getHours()).padStart(2, "0")}`;
  }
  function sumUsageBetween(daily, startKey, endKey) {
    const total = { input: 0, output: 0, cacheRead: 0 };
    for (const [key, bucket] of Object.entries(daily || {})) {
      if (startKey && key < startKey) continue;
      if (endKey && key > endKey) continue;
      total.input += toNonNegativeInteger(bucket?.input);
      total.output += toNonNegativeInteger(bucket?.output);
      total.cacheRead += toNonNegativeInteger(bucket?.cacheRead);
    }
    total.totalTokens = total.input + total.output;
    total.cacheHitRate = total.input > 0 ? total.cacheRead / total.input : null;
    return total;
  }
  function listDayKeysBetween(startKey, endKey) {
    const parse = (key) => {
      const [y, m, d] = String(key).split("-").map(Number);
      return new Date(y, (m || 1) - 1, d || 1);
    };
    const keys = [];
    const end = parse(endKey);
    for (let d = parse(startKey); d <= end; d.setDate(d.getDate() + 1)) {
      keys.push(usageDayKey(d));
    }
    return keys;
  }
  function formatTokenCount(value) {
    const number = toNonNegativeInteger(value);
    if (number >= 1e6) return `${(number / 1e6).toFixed(1).replace(/\.0$/, "")}M`;
    if (number >= 1e3) return `${(number / 1e3).toFixed(1).replace(/\.0$/, "")}k`;
    return String(number);
  }
  function decodeSpeed(outputTokens, durationMs) {
    const output = toNonNegativeInteger(outputTokens);
    const duration = Number(durationMs);
    if (!Number.isFinite(duration) || duration < MIN_SPEED_DURATION_MS || output === 0) return null;
    return Math.round(output / (duration / 1e3));
  }
  function aggregateSpeed(samples, maxSamples = 10, minDurationMs = MIN_SPEED_DURATION_MS) {
    let totalOut = 0;
    let totalMs = 0;
    let counted = 0;
    for (let i = samples.length - 1; i >= 0 && counted < maxSamples; i -= 1) {
      const sample = samples[i];
      const ms = Number(sample?.outMs);
      const output = Number(sample?.output);
      if (Number.isFinite(ms) && ms >= minDurationMs && Number.isFinite(output) && output > 0) {
        totalOut += output;
        totalMs += ms;
        counted += 1;
      }
    }
    return totalMs > 0 ? Math.round(totalOut / (totalMs / 1e3)) : 0;
  }
  function boosterBalanceYuan(wallet) {
    if (!wallet || typeof wallet !== "object") return null;
    const status = String(wallet?.status || "").toUpperCase();
    if (status !== "STATUS_ACTIVE" && status !== "STATUS_ENABLED") return 0;
    const amountLeft = Number(wallet?.balance?.amountLeft);
    return Number.isFinite(amountLeft) ? Math.max(0, amountLeft / 1e8) : null;
  }
  var WIDGET_MODULE_IDS = [
    "header",
    "input",
    "cache",
    "output",
    "speed",
    "duration",
    "quota5h",
    "quotaWeek",
    "usageChart",
    "pet",
    "agents",
    "external"
  ];
  var WIDGET_SHOW_STATES = ["full", "mini", "hidden"];
  var CHART_RANGES = ["day", "week", "month"];
  var PET_STATS = ["daily", "input", "output", "cache", "speed", "balance"];
  var BALL_LINKS = ["none", "console", "subscription"];
  var BALANCE_LINKS = ["subscription", "console"];
  var QUOTA_RESET_FORMATS = ["countdown", "absolute"];
  function defaultWidgetConfig() {
    return {
      version: 3,
      modules: {
        header: { show: "hidden", span: 2, showBalance: true, balanceLink: "subscription" },
        input: { show: "full", span: 1 },
        cache: { show: "full", span: 1 },
        output: { show: "full", span: 1 },
        speed: { show: "full", span: 1 },
        duration: { show: "hidden", span: 1 },
        quota5h: { show: "mini", span: 1, pace: true, resetFormat: "countdown" },
        quotaWeek: { show: "mini", span: 1, pace: true, resetFormat: "countdown" },
        usageChart: { show: "full", span: 2, chartRange: "week" },
        pet: { show: "mini", span: 2, stat: "daily", sidebarTidy: true, ballLink: "none" },
        agents: { show: "hidden", span: 2, hiddenAgents: [] },
        external: { show: "hidden", span: 1, hiddenAccounts: [] }
      },
      orderFull: ["input", "cache", "output", "speed", "usageChart"],
      orderMini: ["pet", "quota5h", "quotaWeek"],
      orderHidden: ["header", "duration", "external", "agents"]
    };
  }
  function normalizeWidgetConfig(raw) {
    const defaults = defaultWidgetConfig();
    const source = raw && typeof raw === "object" ? raw : {};
    const rawModules = source.modules && typeof source.modules === "object" ? { ...source.modules } : {};
    const legacy = source.header && typeof source.header === "object" ? source.header : null;
    if (legacy && !rawModules.header) {
      rawModules.header = {
        show: legacy.showInMini === true ? "mini" : legacy.showInMini === false ? "full" : void 0,
        showBalance: legacy.showBalance,
        balanceLink: legacy.balanceLink
      };
    }
    if ((!Number.isFinite(Number(source.version)) || Number(source.version) < 3) && rawModules.pet) {
      rawModules.pet = { ...rawModules.pet, span: 2 };
    }
    const modules = {};
    for (const id of WIDGET_MODULE_IDS) {
      const fallback = defaults.modules[id];
      const entry = rawModules[id] && typeof rawModules[id] === "object" ? rawModules[id] : {};
      const normalized = {
        show: WIDGET_SHOW_STATES.includes(entry.show) ? entry.show : fallback.show,
        span: entry.span === 2 ? 2 : 1
      };
      if (entry.span == null) normalized.span = fallback.span;
      if (id === "header") {
        normalized.span = 2;
        normalized.showBalance = typeof entry.showBalance === "boolean" ? entry.showBalance : fallback.showBalance;
        normalized.balanceLink = BALANCE_LINKS.includes(entry.balanceLink) ? entry.balanceLink : fallback.balanceLink;
      }
      if (id === "usageChart") {
        normalized.chartRange = CHART_RANGES.includes(entry.chartRange) ? entry.chartRange : fallback.chartRange;
      }
      if (id === "pet") {
        normalized.stat = PET_STATS.includes(entry.stat) ? entry.stat : fallback.stat;
        normalized.sidebarTidy = typeof entry.sidebarTidy === "boolean" ? entry.sidebarTidy : fallback.sidebarTidy;
        normalized.ballLink = BALL_LINKS.includes(entry.ballLink) ? entry.ballLink : fallback.ballLink;
      }
      if (id.startsWith("quota")) {
        normalized.pace = typeof entry.pace === "boolean" ? entry.pace : fallback.pace;
        normalized.resetFormat = QUOTA_RESET_FORMATS.includes(entry.resetFormat) ? entry.resetFormat : fallback.resetFormat;
      }
      if (id === "agents") {
        normalized.span = 2;
        normalized.hiddenAgents = Array.isArray(entry.hiddenAgents) ? entry.hiddenAgents.filter((v) => typeof v === "string") : [];
      }
      if (id === "external") {
        normalized.hiddenAccounts = Array.isArray(entry.hiddenAccounts) ? entry.hiddenAccounts.filter((v) => typeof v === "string") : [];
      }
      modules[id] = normalized;
    }
    const reconcile = (order, region, regionDefaults) => {
      const wanted = WIDGET_MODULE_IDS.filter((id) => modules[id].show === region);
      const stored = Array.isArray(order) ? [...new Set(order.filter((id) => wanted.includes(id)))] : [];
      for (const id of [...regionDefaults, ...WIDGET_MODULE_IDS]) {
        if (wanted.includes(id) && !stored.includes(id)) stored.push(id);
      }
      return stored;
    };
    return {
      version: 3,
      modules,
      orderFull: reconcile(source.orderFull, "full", defaults.orderFull),
      orderMini: reconcile(source.orderMini, "mini", defaults.orderMini),
      orderHidden: reconcile(source.orderHidden, "hidden", defaults.orderHidden)
    };
  }

  // src/panel-app/accumulate.js
  var STORAGE_KEY = "kcm.daily.v1";
  var MAX_DAYS = 90;
  var WRITE_DEBOUNCE_MS = 2e3;
  var mem = null;
  var writeTimer = null;
  function todayKey(now = /* @__PURE__ */ new Date()) {
    const pad = (n) => String(n).padStart(2, "0");
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  }
  function storage() {
    try {
      return globalThis.localStorage || null;
    } catch (error) {
      return null;
    }
  }
  function load() {
    if (mem) return mem;
    mem = {};
    const s = storage();
    if (!s) return mem;
    try {
      const parsed = JSON.parse(s.getItem(STORAGE_KEY) || "null");
      if (parsed && typeof parsed === "object") mem = parsed;
    } catch (error) {
      mem = {};
    }
    return mem;
  }
  function scheduleWrite() {
    if (writeTimer || !storage()) return;
    writeTimer = setTimeout(() => {
      writeTimer = null;
      try {
        storage()?.setItem(STORAGE_KEY, JSON.stringify(mem || {}));
      } catch (error) {
      }
    }, WRITE_DEBOUNCE_MS);
  }
  function noteStepUsage(usage) {
    if (!usage) return;
    const input = Number(usage.inputTokens) || 0;
    const output = Number(usage.outputTokens) || 0;
    const cacheRead = Number(usage.cacheReadTokens) || 0;
    if (!input && !output && !cacheRead) return;
    const map = load();
    const key = todayKey();
    const day = map[key] || (map[key] = { input: 0, output: 0, cacheRead: 0 });
    day.input += input;
    day.output += output;
    day.cacheRead += cacheRead;
    const keys = Object.keys(map).sort();
    while (keys.length > MAX_DAYS) delete map[keys.shift()];
    scheduleWrite();
  }
  function mergeDaily(fileDaily) {
    const out = {};
    for (const [day, rec] of Object.entries(fileDaily || {})) {
      if (rec && typeof rec === "object") out[day] = { ...rec };
    }
    for (const [day, rec] of Object.entries(load())) {
      const cur = out[day];
      const accInput = Number(rec?.input) || 0;
      const curInput = Number(cur?.input) || 0;
      if (!cur || accInput > curInput) {
        out[day] = {
          input: Number(rec.input) || 0,
          output: Number(rec.output) || 0,
          cacheRead: Number(rec.cacheRead) || 0
        };
      }
    }
    return out;
  }
  function hasAccumulated() {
    return Object.keys(load()).length > 0;
  }

  // src/panel-app/status-copy.js
  var STATUS_LONG = {
    loading: "\u6B63\u5728\u52A0\u8F7D\u6570\u636E\u7EDF\u8BA1\u2026",
    fresh: "\u6682\u65E0\u5386\u53F2\u6570\u636E\uFF0C\u4ECE\u73B0\u5728\u5F00\u59CB\u7EDF\u8BA1",
    connecting: "\u672C\u5730\u670D\u52A1\u8FDE\u63A5\u4E2D\uFF0C\u6B63\u5728\u91CD\u8BD5\u2026",
    failing: "\u8FDE\u63A5\u672C\u5730\u670D\u52A1\u5931\u8D25\uFF0C\u6B63\u5728\u81EA\u52A8\u91CD\u8BD5",
    error: "\u6570\u636E\u663E\u793A\u5F02\u5E38\uFF0C\u53EF\u8BA9 Kimi \u5E2E\u5FD9\u81EA\u68C0"
  };
  var STATUS_SHORT = {
    loading: "\u7EDF\u8BA1\u4E2D\u2026",
    fresh: "\u7EDF\u8BA1\u4E2D\u2026",
    connecting: "\u8FDE\u63A5\u4E2D\u2026",
    failing: "\u8FDE\u63A5\u4E2D\u2026",
    error: "\u5F02\u5E38"
  };
  var DISCONNECT_MS = 3e4;
  function summarizeStatus(s = {}) {
    if (s.dispatchError) return "error";
    if (s.fileState === "\u52A0\u8F7D\u5931\u8D25") return "error";
    const wsState = String(s.wsState || "");
    const disconnected = s.kapKnown === false || wsState.startsWith("closed") || wsState === "\u7B49kap\u6E90";
    if (disconnected) return Number(s.connectingMs) >= DISCONNECT_MS ? "failing" : "connecting";
    if (s.connected || s.usageDailyOk || s.hasAccum) return "ok";
    if (s.fileState === "\u65E0\u5386\u53F2") return "fresh";
    return "loading";
  }

  // src/content/utils.js
  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[ch]);
  }
  function fmtDuration(ms) {
    if (!Number.isFinite(ms) || ms <= 0) return "--";
    if (ms < 1e3) return `${Math.round(ms)}ms`;
    if (ms < 6e4) return `${(ms / 1e3).toFixed(1)}s`;
    return `${(ms / 6e4).toFixed(1)}m`;
  }
  function progressClass(percentage) {
    if (percentage >= 80) return "ksb-high";
    if (percentage >= 50) return "ksb-mid";
    return "ksb-low";
  }
  var STATUS_TEXT = {
    idle: "\u7A7A\u95F2",
    thinking: "\u601D\u8003\u4E2D",
    executing: "\u8C03\u7528\u4E2D",
    replying: "\u56DE\u590D\u4E2D",
    offline: "\u672A\u8FDE\u63A5",
    unauthorized: "\u672A\u6388\u6743",
    ratelimit: "\u9650\u6D41\u4E2D",
    subagent: "\u5B50\u4EE3\u7406"
  };
  var PET_ANSWER_STATUSES = ["thinking", "executing", "replying", "subagent", "ratelimit"];
  var CONSOLE_URL = "https://www.kimi.com/code/console";
  var SUBSCRIPTION_URL = "https://www.kimi.com/membership/subscription?tab=quota";
  function parseResetTime(value) {
    const time = Date.parse(value || "");
    return Number.isFinite(time) ? time : null;
  }

  // src/i18n.js
  var PAGE_LOCALE_KEY = "kimi-locale";
  var LOCALE_MIRROR_STORAGE_KEY = "kimi-statusbar.locale";
  var currentLocale = "zh";
  var EN = {
    // 状态
    "\u7A7A\u95F2": "Idle",
    "\u601D\u8003\u4E2D": "Thinking",
    "\u8C03\u7528\u4E2D": "Executing",
    "\u56DE\u590D\u4E2D": "Replying",
    "\u672A\u8FDE\u63A5": "Offline",
    "\u672A\u6388\u6743": "Unauthorized",
    "\u9650\u6D41\u4E2D": "Rate limited",
    "\u5B50\u4EE3\u7406": "Subagent",
    // 模块名
    "\u6807\u9898\u884C": "Header",
    "\u8F93\u5165": "Input",
    "\u7F13\u5B58\u547D\u4E2D": "Cache hit",
    "\u8F93\u51FA": "Output",
    "\u901F\u5EA6": "Speed",
    "\u4E0A\u8F6E\u8017\u65F6": "Last turn",
    "5h \u989D\u5EA6": "5h quota",
    "\u672C\u5468\u989D\u5EA6": "Weekly quota",
    "\u6D88\u8017\u91CF": "Usage",
    "\u5BA0\u7269": "Pet",
    "\u5916\u90E8\u8D26\u6237": "External accounts",
    // 模块内容
    "\u4E0A\u8F6E": "Last",
    "\u672C\u5468": "Week",
    "\u672C\u6708": "Month",
    "\u4F59\u989D --": "Balance --",
    "\u4F59\u989D": "Balance",
    "\u4EE3\u7406": "Agents",
    "\u547D\u4E2D": "Hit",
    "\u4E3B": "main",
    "\u5B50": "sub",
    "\u4E3B\u4EE3\u7406": "Main agent",
    "24h\u6D88\u8017": "24h usage",
    "\u4ECA\u65E5\u6D88\u8017": "Today's usage",
    "7d\u6D88\u8017": "7d usage",
    "30d\u6D88\u8017": "30d usage",
    "\u672C\u5468\u6D88\u8017": "This week",
    "\u9700\u8FDE\u63A5": "Connect",
    "\u9700\u8FDE\u63A5 CLI": "CLI required",
    "\u8FDE\u63A5\u672C\u5730 CLI": "Connect local CLI",
    "\u5F00\u542F24h\u30017d\u300130d\u7EDF\u8BA1": "Enable 24h/7d/30d stats",
    // 独立面板状态文案（status-copy.js 的等级 → 句子，长版给锁位/短版给窄位）
    "\u6B63\u5728\u52A0\u8F7D\u6570\u636E\u7EDF\u8BA1\u2026": "Loading usage stats\u2026",
    "\u6682\u65E0\u5386\u53F2\u6570\u636E\uFF0C\u4ECE\u73B0\u5728\u5F00\u59CB\u7EDF\u8BA1": "No history yet \u2014 counting starts now",
    "\u672C\u5730\u670D\u52A1\u8FDE\u63A5\u4E2D\uFF0C\u6B63\u5728\u91CD\u8BD5\u2026": "Connecting to local service\u2026",
    "\u8FDE\u63A5\u672C\u5730\u670D\u52A1\u5931\u8D25\uFF0C\u6B63\u5728\u81EA\u52A8\u91CD\u8BD5": "Cannot reach local service \u2014 retrying",
    "\u6570\u636E\u663E\u793A\u5F02\u5E38\uFF0C\u53EF\u8BA9 Kimi \u5E2E\u5FD9\u81EA\u68C0": "Display error \u2014 ask Kimi to run a self-check",
    "\u7EDF\u8BA1\u4E2D\u2026": "Counting\u2026",
    "\u8FDE\u63A5\u4E2D\u2026": "Connecting\u2026",
    "\u5373\u5C06\u91CD\u7F6E": "Resetting soon",
    "{days}\u5929{hours}\u5C0F\u65F6\u540E\u91CD\u7F6E": "Resets in {days}d {hours}h",
    "{hours}\u5C0F\u65F6{minutes}\u5206\u949F\u540E\u91CD\u7F6E": "Resets in {hours}h {minutes}m",
    "{totalMin}\u5206\u949F\u540E\u91CD\u7F6E": "Resets in {totalMin}m",
    "\u7B2C{n}\u6B65 \xB7 \u672C\u8F6E\u7ED3\u675F": "Step {n} \xB7 turn ended",
    "\u7B2C{n}\u6B65": "Step {n}",
    "\u5B50\u4EE3\u7406 {index}": "Subagent {index}",
    "\u6388\u6743\u542F\u52A8\u5931\u8D25\uFF1A{msg}": "Authorization failed to start: {msg}",
    "\u989D\u5EA6\u66F4\u65B0\u5931\u8D25\uFF1A{msg}": "Quota update failed: {msg}",
    "\u7F13\u5B58\u547D\u4E2D {pct}": "Cache hit {pct}",
    "\u5468\u65E5": "Sun",
    "\u5468\u4E00": "Mon",
    "\u5468\u4E8C": "Tue",
    "\u5468\u4E09": "Wed",
    "\u5468\u56DB": "Thu",
    "\u5468\u4E94": "Fri",
    "\u5468\u516D": "Sat",
    "\u83B7\u53D6\u5931\u8D25": "Failed",
    "\u5DF2\u542F\u7528": "Enabled",
    "\u5728\u6269\u5C55\u5F39\u7A97\u4E2D\u914D\u7F6E API Key": "Configure API Key in the extension popup",
    "\u4F7F\u7528 kimi-code-monitor \u6280\u80FD\uFF0C\u8BA9 Kimi \u914D\u7F6E\u5916\u90E8\u8D26\u6237": "Use the kimi-code-monitor skill to let Kimi configure external accounts",
    "API\u4F59\u989D": "API balance",
    "\u6682\u65E0\u5DF2\u914D\u7F6E\u8D26\u6237": "No accounts configured",
    // 面板交互
    "\u70B9\u51FB\u91CD\u7F6E\u5E76\u91CD\u65B0\u62C9\u53D6\u6570\u636E": "Click to reset and refetch",
    "\u6253\u5F00 Kimi Code \u63A7\u5236\u53F0": "Open Kimi Code console",
    "\u67E5\u770B / \u5145\u503C\u989D\u5EA6": "View / top up quota",
    "\u6A21\u5757\u8BBE\u7F6E": "Module settings",
    "\u9690\u85CF\u533A \xB7 \u62D6\u5230\u4E0B\u65B9\u542F\u7528": "Hidden \xB7 drag below to enable",
    "\u5C55\u5F00\u533A \xB7 \u5C55\u5F00\u65F6\u663E\u793A": "Expanded \xB7 shown when expanded",
    "\u56FA\u5B9A\u533A \xB7 \u59CB\u7EC8\u663E\u793A": "Pinned \xB7 always visible",
    "\u9690\u85CF\u533A\uFF08\u9876\u90E8\uFF09": "Hidden (top)",
    "\u5C55\u5F00\u533A\uFF08\u4E2D\u95F4\uFF09\xB7 \u5C55\u5F00\u65F6\u663E\u793A": "Expanded (middle) \xB7 shown when expanded",
    "\u56FA\u5B9A\u533A\uFF08\u5E95\u90E8\uFF09\xB7 Mini \u4E5F\u4FDD\u7559": "Pinned (bottom) \xB7 kept in Mini mode",
    "Mini \u6A21\u5F0F\uFF1A\u70B9\u51FB\u4E0B\u65B9\u533A\u57DF\u5C55\u5F00": "Mini mode: click the bottom area to expand",
    "Kimi Status \u5DF2\u8FDE\u63A5": "Kimi Status connected",
    "\u7F16\u8F91\u6A21\u5F0F\uFF1A\u62D6\u62FD\u6A21\u5757\u6392\u5E8F\uFF0C\u70B9 \u2261 \u914D\u7F6E\uFF0CEsc \u6216\u70B9\u7A7A\u767D\u5904\u5B8C\u6210": "Edit mode: drag to reorder, \u2261 to configure, Esc or click blank to finish",
    "\u663E\u793A": "Show",
    "\u9690\u85CF": "Hide",
    "\u5145\u503C\u9875": "Top-up page",
    "\u63A7\u5236\u53F0": "Console",
    "\u534A\u5BBD": "Half",
    "\u6574\u5BBD": "Full",
    "\u663E\u793A\u4EE3\u7406": "Show agents",
    "\u663E\u793A\u8D26\u6237": "Show accounts",
    "\u7EDF\u8BA1\u8303\u56F4": "Range",
    "\u5300\u901F\u53C2\u7167\u7EBF": "Pace reference",
    "\u91CD\u7F6E\u65F6\u95F4\u663E\u793A": "Reset time format",
    "\u5012\u8BA1\u65F6": "Countdown",
    "\u5177\u4F53\u65F6\u95F4": "Absolute time",
    "\u53F3\u4FA7\u6570\u636E": "Right-side stat",
    "\u70B9\u51FB\u5C0F\u7403\u8DF3\u8F6C": "Ball click link",
    "\u65E0\u8DF3\u8F6C": "None",
    "\u4FA7\u680F\u6539\u9020\uFF08\u53BB logo \u4E0A\u79FB\uFF09": "Sidebar tidy (hide logo)",
    "\u5F00\u542F": "On",
    "\u5173\u95ED": "Off",
    // 授权与连接提示
    "\u70B9\u51FB\u5B8C\u6210 Kimi \u6388\u6743": "Click to authorize Kimi",
    "\u70B9\u51FB\u6388\u6743 Kimi \u989D\u5EA6\u67E5\u8BE2": "Click to authorize quota query",
    "\u6B63\u5728\u6253\u5F00 Kimi \u6388\u6743\u9875\u2026": "Opening Kimi authorization\u2026",
    "\u65E0\u6CD5\u5F00\u59CB\u6388\u6743": "Cannot start authorization",
    "\u6388\u6743\u4E2D\uFF0C\u5B8C\u6210\u540E\u81EA\u52A8\u6062\u590D": "Authorizing, resumes automatically",
    "\u8BF7\u5728\u65B0\u6253\u5F00\u7684\u9875\u9762\u5B8C\u6210\u6388\u6743": "Complete authorization in the new page",
    "\u6388\u6743\u542F\u52A8\u5931\u8D25": "Authorization failed to start",
    "WebSocket \u8FDE\u7EED\u91CD\u8FDE\u5931\u8D25\uFF0C\u5DF2\u6682\u505C\u81EA\u52A8\u91CD\u8FDE": "WebSocket reconnect failed repeatedly, auto-reconnect paused",
    "\u7B49\u5F85 server_hello \u8D85\u65F6\uFF0C\u6B63\u5728\u91CD\u8FDE\u2026": "server_hello timeout, reconnecting\u2026",
    // 引导
    "Mini \u6A21\u5F0F": "Mini mode",
    "\u81EA\u5B9A\u4E49\u5E03\u5C40": "Custom layout",
    "\u5B8C\u6210\uFF0C\u8FDB\u5165\u7F16\u8F91\u6A21\u5F0F": "Done \xB7 enter edit mode",
    "<b>\u70B9\u6700\u5E95\u90E8\u8FD9\u4E00\u533A\u57DF</b>\u628A\u9762\u677F\u6536\u6210\u4E00\u884C\uFF0C\u518D\u70B9\u4E00\u6B21\u5C55\u5F00\u3002\u54EA\u4E9B\u6A21\u5757\u7559\u5728 Mini \u53EF\u5728\u7F16\u8F91\u6A21\u5F0F\u91CC\u8C03\u6574\u3002": "<b>Click the bottom area</b> to collapse the panel to one line; click again to expand. Which modules stay in Mini is adjustable in edit mode.",
    "\u7A7A\u95F2\u65F6\u663E\u793A\u5F53\u524D<b>\u65F6\u95F4</b>\uFF0C\u5DE5\u4F5C\u65F6\u81EA\u52A8<b>\u8BA1\u65F6</b>\u3002\u70B9\u5C0F\u7403\u64AD\u4E00\u6BB5\u52A8\u753B\u3002": "Shows the current <b>time</b> when idle and <b>counts up</b> while working. Click the ball to play an animation.",
    '<span class="ksb-walk-hl">\u957F\u6309\u9762\u677F\u4EFB\u610F\u4F4D\u7F6E</span>\u8FDB\u5165\u7F16\u8F91\u6A21\u5F0F\uFF0C\u62D6\u52A8\u6A21\u5757\u5230\u4E0D\u540C\u533A\u57DF\u6539\u53D8\u663E\u793A\u65B9\u5F0F\uFF1B\u70B9\u6A21\u5757\u53F3\u4E0A\u89D2 <b>\u2261</b> \u8C03\u5BBD\u5EA6\u548C\u4E13\u5C5E\u8BBE\u7F6E\u3002': '<span class="ksb-walk-hl">Long-press anywhere on the panel</span> to enter edit mode. Drag modules between zones; click <b>\u2261</b> on a module for width and per-module settings.',
    // 连接提示
    "WebSocket \u8FDE\u63A5\u5EFA\u7ACB\u8D85\u65F6\uFF0C\u6B63\u5728\u91CD\u8BD5\u2026": "WebSocket connection timed out, retrying\u2026",
    "WebSocket \u8FDE\u63A5\u5931\u8D25": "WebSocket connection failed",
    "WebSocket \u5DF2\u65AD\u5F00\uFF08{code}{reason}\uFF09\uFF0C\u6B63\u5728\u91CD\u8FDE\u2026": "WebSocket closed ({code}{reason}), reconnecting\u2026",
    // 其他动态串
    "{date} \xB7 \u4E3B {main} \xB7 \u5B50 {sub}": "{date} \xB7 main {main} \xB7 sub {sub}",
    "\u8D60\u9001 {granted} \xB7 \u5145\u503C {paid}": "Granted {granted} \xB7 Paid {paid}",
    "\u91CD\u7F6E {time}": "Resets {time}",
    "\u5BBD\u5EA6": "Width",
    "\u4F59\u989D\u70B9\u51FB\u8DF3\u8F6C": "Balance click link",
    /* ---------- popup ---------- */
    "\u5F53\u524D": "Current",
    "\u5207\u6362": "Switch",
    "\u5207\u6362\u5931\u8D25": "Switch failed",
    "\u6539\u540D": "Rename",
    "\u91CD\u65B0\u6388\u6743": "Re-authorize",
    "\u79FB\u9664": "Remove",
    "\u79FB\u9664\u5931\u8D25": "Remove failed",
    "\u4FDD\u5B58": "Save",
    "\u6539\u540D\u5931\u8D25": "Rename failed",
    "\uFF08\u9700\u91CD\u65B0\u6388\u6743\uFF09": " (needs reauth)",
    "{name}\u5931\u8D25\uFF1A{msg}": "{name} failed: {msg}",
    "\u6539\u540D\u5931\u8D25\uFF1A{msg}": "Rename failed: {msg}",
    "\u79FB\u9664\u5931\u8D25\uFF1A{msg}": "Remove failed: {msg}",
    "\u83B7\u53D6\u5931\u8D25\uFF1A{msg}": "Failed: {msg}",
    "\u8BF7\u5728\u6388\u6743\u9875\u5B8C\u6210\u6388\u6743\u3002": "Complete authorization in the opened page.",
    "\u72B6\u6001\u67E5\u8BE2\u5931\u8D25\uFF1A{msg}": "Status query failed: {msg}",
    "\u9A8C\u8BC1\u7801\uFF1A": "Code: ",
    "\u5DF2\u5728\u65B0\u6807\u7B7E\u9875\u6253\u5F00\u6388\u6743\u9875\uFF0C\u8BF7\u5B8C\u6210\u6388\u6743\uFF1B\u5173\u95ED\u672C\u5F39\u7A97\u4E0D\u5F71\u54CD\u6388\u6743\u3002": "The authorization page opened in a new tab \u2014 complete it there; closing this popup does not affect the process.",
    "\u6388\u6743\u6210\u529F\uFF0C\u72B6\u6001\u680F\u4F1A\u81EA\u52A8\u6062\u590D\u663E\u793A\u3002": "Authorized. The status bar will resume automatically.",
    "\u6388\u6743\u672A\u5B8C\u6210\uFF08\u5DF2\u8D85\u65F6\u6216\u88AB\u53D6\u6D88\uFF09\uFF0C\u8BF7\u91CD\u8BD5\u3002": "Authorization not completed (timed out or cancelled) \u2014 please retry.",
    "\u4F59\u989D\u6570\u636E\u5F02\u5E38": "Abnormal balance data",
    "\u7A97\u53E3\u6570\u636E\u5F02\u5E38": "Abnormal window data",
    "\u4F59\u989D {total}\uFF08\u8D60\u9001 {granted} \xB7 \u5145\u503C {paid}\uFF09": "Balance {total} (granted {granted} \xB7 paid {paid})",
    "\u72B6\u6001\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u5237\u65B0": "Failed to read status, please refresh",
    "\u8BF7\u5148\u7C98\u8D34 API Key": "Paste an API Key first",
    "\u6B63\u5728\u9A8C\u8BC1\u2026": "Verifying\u2026",
    "\u672A\u6388\u4E88\u57DF\u540D\u8BBF\u95EE\u6743\u9650": "Domain access not granted",
    "\u4FDD\u5B58\u5931\u8D25": "Save failed",
    "\u5DF2\u4FDD\u5B58": "Saved",
    "\u7D2F\u8BA1\u547D\u540D {calls} \u6B21 \xB7 \u8F93\u5165 {input} \xB7 \u8F93\u51FA {output} tokens": "Named {calls} times \xB7 input {input} \xB7 output {output} tokens",
    "\u5C1A\u672A\u5B89\u88C5\u5BA0\u7269": "No pets installed",
    "\u4E0B\u8F7D\u4E2D\u2026": "Downloading\u2026",
    "\u5B89\u88C5\u6210\u529F\uFF0C\u5DF2\u5207\u6362\u4E3A\u65B0\u5BA0\u7269": "Installed \u2014 switched to the new pet",
    "\u5B89\u88C5\u5931\u8D25\uFF1A{msg}": "Install failed: {msg}",
    "\u5DF2\u4E0B\u8F7D \u2713": "Downloaded \u2713",
    "\u4E0B\u8F7D\u5931\u8D25": "Download failed",
    "\u5DF2\u590D\u5236 \u2713": "Copied \u2713",
    "\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u7528\u4E0B\u8F7D": "Copy failed \u2014 use download",
    "{date} \xB7 \u65E0\u8BB0\u5F55": "{date} \xB7 no record",
    "\uFF08\u4E3B {main} \xB7 \u5B50 {sub}\uFF09": " (main {main} \xB7 sub {sub})",
    "\u8BFB\u53D6\u5931\u8D25": "Read failed",
    "\u8BFB\u53D6\u5931\u8D25\uFF1A{msg}": "Read failed: {msg}",
    "\u5BFC\u51FA\u5931\u8D25": "Export failed",
    "\u5BFC\u51FA\u7EDF\u8BA1": "Export stats",
    "\u6388\u6743\u672C\u5730 CLI": "Authorize local CLI",
    "\u6B63\u5728\u8BFB\u53D6\u672C\u5730\u8BB0\u5F55 {pct}%": "Reading local records {pct}%",
    "\u672C\u5730\u8BB0\u5F55\u5DF2\u6388\u6743": "Local records authorized",
    "\u72B6\u6001\u8BFB\u53D6\u5931\u8D25": "Failed to read status",
    "\u8FDE\u63A5\u72B6\u6001\u5F02\u5E38\uFF0C\u8BF7\u91CD\u8BD5": "Connection abnormal, please retry",
    "\u672C\u5730\u8BB0\u5F55\u8BFB\u53D6\u5931\u8D25": "Failed to read local records",
    "\u5F53\u524D Chrome \u4E0D\u652F\u6301\u76EE\u5F55\u6388\u6743": "This Chrome does not support directory access",
    "\u6B63\u5728\u6062\u590D\u6388\u6743\u2026": "Restoring access\u2026",
    "\u8BF7\u9009\u62E9 .kimi-code \u6587\u4EF6\u5939\u2026": "Choose the .kimi-code folder\u2026",
    "\u76EE\u5F55\u9009\u62E9\u9519\u8BEF\uFF1A\u8BF7\u9009\u62E9 .kimi-code \u6587\u4EF6\u5939\u3002": "Wrong folder: choose the .kimi-code folder.",
    "\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5": "Connection failed, please retry",
    "\u65AD\u5F00\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5": "Disconnect failed, please retry",
    "\u5EFA\u8BAE\u8DEF\u5F84\uFF1A<code>~/.kimi-code</code><br>\u76EE\u5F55\u9009\u62E9\u5668\u4E2D\u6309 <b>\u2318\u21E7.</b> \u663E\u793A\u9690\u85CF\u76EE\u5F55\u3002": "Suggested path: <code>~/.kimi-code</code><br>Press <b>\u2318\u21E7.</b> in the directory picker to show hidden folders.",
    "\u5EFA\u8BAE\u8DEF\u5F84\uFF1A<code>%USERPROFILE%\\.kimi-code</code><br>\u53EF\u6309 <b>Ctrl+L</b> \u540E\u7C98\u8D34\u8DEF\u5F84\u5E76\u56DE\u8F66\u3002": "Suggested path: <code>%USERPROFILE%\\.kimi-code</code><br>Press <b>Ctrl+L</b>, paste the path and press Enter.",
    "\u5EFA\u8BAE\u8DEF\u5F84\uFF1A<code>~/.kimi-code</code><br>\u76EE\u5F55\u9009\u62E9\u5668\u4E2D\u6309 <b>Ctrl+H</b> \u663E\u793A\u9690\u85CF\u76EE\u5F55\u3002": "Suggested path: <code>~/.kimi-code</code><br>Press <b>Ctrl+H</b> in the directory picker to show hidden folders.",
    // popup.html 静态串（applyPopupI18n 的叶子文本与属性）
    "\u7EDF\u8BA1\u6307\u6807": "Stats metric",
    "\u6D3B\u8DC3\u70ED\u529B\u56FE": "Activity heatmap",
    "\u8D77\u59CB\u65E5\u671F": "Start date",
    "\u7ED3\u675F\u65E5\u671F": "End date",
    "\u5206\u4EAB\u7528\u91CF": "Share usage",
    "\u53D6\u6D88": "Cancel",
    "\u5F00\u542F\u957F\u671F\u7528\u91CF\u7EDF\u8BA1": "Enable long-term usage stats",
    "\u6388\u6743\u8BFB\u53D6\u672C\u673A Kimi CLI \u4F7F\u7528\u8BB0\u5F55\uFF0C\u7528\u4E8E7\u5929\u300130\u5929\u7EDF\u8BA1\u3002\u4E0D\u4F1A\u4FDD\u5B58\u6216\u4E0A\u4F20\u5BF9\u8BDD\u5185\u5BB9\u3002": "Authorize reading local Kimi CLI usage records for 7-day and 30-day stats. Conversation content is never saved or uploaded.",
    "Kimi \u8D26\u6237": "Kimi accounts",
    "\u53BB\u6388\u6743": "Authorize",
    "\u5907\u6CE8\u540D\uFF08\u53EF\u7559\u7A7A\uFF0C\u6388\u6743\u540E\u53EF\u6539\uFF09": "Label (optional, editable after auth)",
    "+ \u6DFB\u52A0\u8D26\u6237": "+ Add account",
    "\u7C98\u8D34 API Key": "Paste API Key",
    "\u684C\u9762\u5BA0\u7269": "Desktop pet",
    "+ \u6DFB\u52A0\u5BA0\u7269": "+ Add pet",
    "\u7C98\u8D34\u5BA0\u7269\u5B89\u88C5 bash \u547D\u4EE4": "Paste pet install bash command",
    "\u5B89\u88C5": "Install",
    "\u5BA0\u7269\u5927\u5C0F": "Pet size",
    "\u91CD\u7F6E": "Reset",
    "\u653E\u5927": "Enlarge",
    "\u7F29\u5C0F": "Shrink",
    "\u65B0\u4F1A\u8BDD AI \u81EA\u52A8\u547D\u540D": "AI auto-rename for new sessions",
    "\u4F7F\u7528\u6A21\u578B": "Model",
    "\u547D\u540D\u6A21\u578B": "Naming model",
    "\u6807\u9898\u5E26 emoji": "Emoji in title",
    "\u6253\u5F00": "On",
    "\u68C0\u67E5\u66F4\u65B0": "Check for updates",
    "\u63A8\u8350\u753B\u5ECA\uFF1A": "Galleries: ",
    "\u7528\u91CF\u5206\u4EAB\u5361\u7247\u9884\u89C8": "Usage share card preview",
    "\u4E0B\u8F7D PNG": "Download PNG",
    "\u590D\u5236\u56FE\u7247": "Copy image",
    "\u9762\u677F\u989D\u5EA6\u6761\u663E\u793A\u5F53\u524D\u8D26\u6237\u7684 5 \u5C0F\u65F6\u4E0E\u672C\u5468\u989D\u5EA6\u3002": "The panel quota bars show the current account's 5-hour and weekly quota.",
    "\u6DFB\u52A0\u540E\uFF0C\u9762\u677F\u300C\u5916\u90E8\u8D26\u6237\u300D\u6A21\u5757\u4F1A\u663E\u793A\u5BF9\u5E94\u4F59\u989D/\u989D\u5EA6\uFF0CKey \u53EA\u4FDD\u5B58\u5728\u672C\u673A\u6269\u5C55\u5B58\u50A8\u4E2D\u3002": 'After adding, the panel "External accounts" module shows its balance/quota. Keys are stored only in local extension storage.',
    "\u5230 codexpet.top \u6216 petdex.dev \u6311\u9009\u559C\u6B22\u7684\u5BA0\u7269\uFF0C\u590D\u5236\u5B83\u7684\u5B89\u88C5\u547D\u4EE4\uFF08\u90A3\u6BB5 bash\uFF09\uFF0C\u56DE\u5230\u8FD9\u91CC\u70B9\u300C+ \u6DFB\u52A0\u5BA0\u7269\u300D\u7C98\u8D34\u5373\u53EF\u3002<br><br>\u5BA0\u7269\u7D20\u6750\u6765\u81EA\u793E\u533A\u5206\u4EAB\uFF0C\u5176\u6743\u5229\u5F52\u5C5E\u4E0E\u4F7F\u7528\u9650\u5236\u4EE5\u5404\u53D1\u5E03\u9875\u9762\u4E3A\u51C6\uFF1B\u672C\u6269\u5C55\u4EC5\u63D0\u4F9B\u672C\u5730\u64AD\u653E\u529F\u80FD\uFF0C\u4E0D\u6301\u6709\u4E5F\u4E0D\u62C5\u4FDD\u7D20\u6750\u7684\u4EFB\u4F55\u6743\u5229\u3002": 'Pick a pet at codexpet.top or petdex.dev, copy its install command (the bash snippet), and paste it here via "+ Add pet".<br><br>Pet assets are shared by the community; their rights and usage limits belong to the respective publishers. This extension only provides local playback and holds no rights to the assets.',
    "\u8BFB\u53D6\u4F1A\u8BDD\u7684\u9996\u6761\u4E0E\u6700\u8FD1\u6D88\u606F\uFF0C\u7531\u6240\u9009\u6A21\u578B\u751F\u6210\u7B80\u77ED\u6807\u9898\u5199\u56DE\u4FA7\u8FB9\u680F\uFF1B\u624B\u52A8\u6539\u8FC7\u7684\u540D\u5B57\u4E0D\u4F1A\u88AB\u8986\u76D6\u3002<br><br>\u5F00\u542F\u81EA\u52A8\u547D\u540D\u540E\uFF0C\u65B0\u4F1A\u8BDD\u5728\u7B2C 3 \u8F6E\u5BF9\u8BDD\u7ED3\u675F\u540E\u624D\u547D\u540D\uFF08\u9996\u8F6E\u5185\u5BB9\u592A\u5C11\u4E0D\u8DB3\u4EE5\u6982\u62EC\uFF09\u3002<br><br>\u6B64\u529F\u80FD\u4F1A\u989D\u5916\u6D88\u8017 token\uFF1A\u6BCF\u6B21\u91CD\u547D\u540D\u8F93\u5165\u7EA6 1500~2500 tokens\uFF08\u4E0A\u4E0B\u6587\u6709 2000 \u5B57\u7B26\u786C\u4E0A\u9650\uFF09\uFF0C\u8F93\u51FA\u51E0\u5341\u5230\u51E0\u767E tokens\u3002\u4E0B\u65B9\u8BA1\u6570\u5668\u663E\u793A\u7D2F\u8BA1\u6D88\u8017\u3002": "Reads the first and latest messages of a session and asks the selected model for a short title written back to the sidebar; manually renamed titles are never overwritten.<br><br>With auto-rename on, new sessions are named only after turn 3 (too little content earlier).<br><br>This feature consumes extra tokens: about 1500\u20132500 input tokens per rename (2,000-char context cap) and tens to hundreds of output tokens. The counter below shows the cumulative usage.",
    /* ---------- 收藏 + 分享卡片 ---------- */
    "\u5DF2\u5F00\u542F\u5B9E\u9A8C\u6027\u300C\u591A\u6807\u7B7E\u9875\u4FA7\u680F\u300D\uFF0C\u9875\u9762\u5373\u5C06\u5237\u65B0\u4EE5\u751F\u6548\u2026": 'Enabled the experimental "Multi-tab sidebar"; refreshing the page to apply\u2026',
    "[close]\u5173\u95ED": "Close",
    "\u6536\u85CF": "Bookmark",
    "\u53D6\u6D88\u6536\u85CF": "Remove bookmark",
    "AI \u56DE\u590D": "AI reply",
    "\u672A\u547D\u540D\u4F1A\u8BDD": "Untitled session",
    "\u6309\u4F1A\u8BDD\u5206\u7EC4": "Group by session",
    "\u6700\u65E9\u5728\u524D": "Oldest first",
    "\u6700\u65B0\u5728\u524D": "Newest first",
    "\u6279\u91CF\u7BA1\u7406": "Manage",
    "\u5217\u8868": "List",
    "\u5361\u7247": "Cards",
    "\u5168\u9009": "Select all",
    "\u5220\u9664\u6240\u9009\uFF08{n}\uFF09": "Delete selected ({n})",
    "\u5B8C\u6210": "Done",
    "\u6682\u65E0\u6536\u85CF\u5185\u5BB9\u3002\u53EF\u5728 AI \u56DE\u590D\u4E0B\u65B9\u7684\u64CD\u4F5C\u680F\u4E2D\u70B9\u51FB\u661F\u6807\uFF0C\u5C06\u56DE\u590D\u52A0\u5165\u6536\u85CF\u3002": "No bookmarks yet. Click the star in the action bar below an AI reply to bookmark it.",
    "\u6536\u85CF\u8BE6\u60C5": "Bookmark detail",
    "\u7528\u6237\u63D0\u95EE": "Your question",
    "\uFF08\u6536\u85CF\u65F6\u672A\u8BB0\u5F55\u63D0\u95EE\uFF09": "(question not recorded when bookmarked)",
    "\u8DF3\u8F6C\u5230\u539F\u6587 \u2192": "Jump to original \u2192",
    "\u6536\u85CF\u76EE\u5F55": "Bookmark outline",
    "\u5BFC\u51FA\u6536\u85CF": "Export bookmarks",
    "\u6536\u85CF\u5BFC\u51FA": "Bookmark export",
    "\u5BFC\u51FA\u4E8E {date} \xB7 \u5171 {n} \u6761": "Exported {date} \xB7 {n} items",
    // 分享卡片 SVG
    "Kimi Code \u7528\u91CF": "Kimi Code Usage",
    "\u6BCF\u65E5\u6D88\u8017": "Daily usage",
    "\u7F13\u5B58\u547D\u4E2D {pct}%": "Cache hit {pct}%",
    "\u5CF0\u503C {date} \xB7 {value}": "Peak {date} \xB7 {value}",
    "\u6D3B\u8DC3\u70ED\u529B\u56FE \xB7 {n} \u5929": "Activity heatmap \xB7 {n}d",
    "\u8303\u56F4\u6C47\u603B": "Summary",
    "\u6D3B\u8DC3\u5929\u6570": "Active days",
    "{a} / {b} \u5929": "{a} / {b} d",
    "\u65E5\u5747\u6D88\u8017": "Daily average",
    "{v} / \u5929": "{v} / day",
    "\u5CF0\u503C\u65E5": "Peak day",
    "\u603B\u6D88\u8017": "Total",
    /* ---------- 动态站点授权 ---------- */
    "\u6B64\u7AD9\u70B9\u672A\u542F\u7528\u9762\u677F": "Panel not enabled on this site",
    "\u5DF2\u5728\u6B64\u7AD9\u70B9\u542F\u7528\u9762\u677F": "Panel enabled on this site",
    "\u5728\u6B64\u7AD9\u70B9\u542F\u7528": "Enable on this site",
    "\u91CD\u65B0\u542F\u7528": "Re-enable",
    "\u672A\u6388\u4E88\u7AD9\u70B9\u8BBF\u95EE\u6743\u9650": "Site access not granted",
    "\u542F\u7528\u5931\u8D25": "Failed to enable",
    "\u53D6\u6D88\u5931\u8D25": "Failed to disable",
    /* ---------- 扩展功能卡片（收藏开关 / 自动归档 / 自动命名） ---------- */
    "\u6269\u5C55\u529F\u80FD": "Extensions",
    "AI \u56DE\u590D\u6536\u85CF\uFF1A\u70B9\u51FB AI \u56DE\u590D\u4E0B\u65B9\u7684\u661F\u6807\u5373\u53EF\u6536\u85CF\uFF0C\u5728\u4FA7\u680F\u968F\u65F6\u56DE\u770B\uFF1B\u5185\u5BB9\u53EA\u4FDD\u5B58\u5728\u672C\u5730\u3002<br><br>\u81EA\u52A8\u5F52\u6863\u4E0D\u6D3B\u8DC3\u5BF9\u8BDD\uFF1A\u6309\u9759\u9ED8\u5929\u6570\u628A\u4E0D\u6D3B\u8DC3\u7684\u5BF9\u8BDD\u81EA\u52A8\u79FB\u5165\u300C\u5DF2\u5B8C\u6210\u300D\uFF0C\u4FDD\u6301\u300C\u8FDB\u884C\u4E2D\u300D\u5217\u8868\u5E72\u51C0\u3002": 'AI reply bookmarks: click the star below an AI reply to bookmark it and revisit from the sidebar; content stays on this device.<br><br>Auto-archive inactive chats: moves inactive sessions to "Done" after their idle days threshold, keeping the "Open" list clean.',
    "AI \u56DE\u590D\u6536\u85CF": "AI reply bookmarks",
    "\u81EA\u52A8\u5F52\u6863\u4E0D\u6D3B\u8DC3\u5BF9\u8BDD": "Auto-archive inactive chats",
    "\u6CA1\u6709\u7B26\u5408\u6761\u4EF6\u7684\u5BF9\u8BDD": "No sessions match the rules",
    "\u70B9\u51FB\u89E3\u9501\u81EA\u52A8\u5F52\u6863": "Click to unlock auto-archive",
    "\u5355\u65E5\u5BF9\u8BDD = \u521B\u5EFA\u540E\u4E0D\u5230 2 \u5929\u7684\u77ED\u4F1A\u8BDD\uFF08\u5F53\u5929\u4E00\u6B21\u6027\u4EFB\u52A1\uFF09\uFF0C\u9759\u9ED8\u8FBE\u5230\u5929\u6570\u5373\u81EA\u52A8\u5F52\u6863": "Single-day = short sessions used within 2 days of creation (one-off tasks); archived automatically after the idle threshold.",
    "\u591A\u65E5\u5BF9\u8BDD = \u8DE8 2 \u5929\u4EE5\u4E0A\u6301\u7EED\u4F7F\u7528\u7684\u4F1A\u8BDD\uFF08\u9694\u51E0\u5929\u56DE\u6765\u4E00\u6B21\uFF09\uFF0C\u9759\u9ED8\u8FBE\u5230\u5929\u6570\u5373\u81EA\u52A8\u5F52\u6863": "Multi-day = sessions used across more than 2 days (revisited every few days); archived automatically after the idle threshold.",
    "\u6240\u6709\u5BF9\u8BDD = \u4E0D\u8BBA\u6D3B\u8DC3\u8DE8\u5EA6\uFF0C\u53EA\u8981\u9759\u9ED8\u8FBE\u5230\u5929\u6570\u5C31\u81EA\u52A8\u5F52\u6863\uFF08\u515C\u5E95\u89C4\u5219\uFF09": "Any session = regardless of active span, archived automatically once the idle threshold is reached (fallback rule).",
    "\u6BCF 24 \u5C0F\u65F6\u540E\u53F0\u81EA\u52A8\u5F52\u6863\u4E00\u6B21": "Auto-archives in the background every 24 hours",
    "\u6BCF 24 \u5C0F\u65F6\u540E\u53F0\u81EA\u52A8\u5F52\u6863\u4E00\u6B21\uFF1B\u4E0A\u6B21\uFF1A{time}\uFF0C\u5F52\u6863 {n} \u4E2A\u5BF9\u8BDD": "Auto-archives every 24 hours; last run {time}, {n} sessions archived",
    "\u8D26\u6237 {n}": "Account {n}",
    "\u5355\u65E5\u5BF9\u8BDD\uFF0C\u9759\u9ED8": "Single-day, idle \u2265",
    "\u591A\u65E5\u5BF9\u8BDD\uFF0C\u9759\u9ED8": "Multi-day, idle \u2265",
    "\u6240\u6709\u5BF9\u8BDD\uFF0C\u9759\u9ED8": "Any session, idle \u2265",
    "\u5929\u540E\u5F52\u6863": "days",
    "\u5DF2\u6539\u7531\u5B98\u65B9\u5B9E\u9A8C\u300CAI session titles\u300D\u5B9E\u73B0\uFF0C\u672A\u5F00\u542F\u65F6\u70B9\u51FB\u590D\u5236\u63D0\u793A\u8BCD\uFF0C\u53D1\u7ED9 Kimi \u5373\u53EF\u5F00\u542F\u3002": 'Now powered by the official Kimi CLI experiment "AI session titles". If it is not enabled yet, click Copy prompt and send it to Kimi to switch on.',
    "\u590D\u5236\u63D0\u793A\u8BCD": "Copy prompt",
    "\u5DF2\u590D\u5236\uFF0C\u7C98\u8D34\u5230 kimi \u5BF9\u8BDD\u6846\u53D1\u9001\u5373\u53EF": "Copied \u2014 paste it into the kimi chat and send",
    "\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u624B\u52A8\u64CD\u4F5C": "Copy failed \u2014 please copy manually",
    "\u91CD\u8BD5": "Retry",
    "\u6E05\u7406\u5E76\u89E3\u9501\u81EA\u52A8\u5F52\u6863": "Archive them & unlock auto-archive",
    "\u2026\u2026\u4EE5\u53CA\u5176\u4ED6 {m} \u4E2A\u5BF9\u8BDD": "\u2026 and {m} more sessions",
    "\u6709 {n} \u6761\u5BF9\u8BDD\u5F85\u5F52\u6863": "{n} sessions ready to archive",
    "\u64CD\u4F5C\u5931\u8D25": "Operation failed",
    "\u5DF2\u89E3\u9501\u81EA\u52A8\u5F52\u6863": "Auto-archive unlocked",
    "\u64CD\u4F5C\u5931\u8D25\uFF1A{msg}": "Operation failed: {msg}",
    "\u5DF2\u79FB\u5165\u300C\u5DF2\u5B8C\u6210\u300D{n} \u4E2A\u5BF9\u8BDD": 'Moved {n} sessions to "Done"',
    "\u6B63\u5728\u8BFB\u53D6\u4F1A\u8BDD\u5217\u8868\u2026": "Loading sessions\u2026",
    "\u5DF2\u5F00\u542F Kimi Web \u5B9E\u9A8C\u6027\u300C\u591A\u6807\u7B7E\u9875\u4FA7\u680F\u300D\uFF0C\u9875\u9762\u5373\u5C06\u5237\u65B0\u2026": 'Enabled the Kimi Web experimental "Multi-tab sidebar"; refreshing the page\u2026',
    "\u6BCF 24 \u5C0F\u65F6\u540E\u53F0\u81EA\u52A8\u6574\u7406\u4E00\u6B21": "Tidies automatically every 24 hours",
    "\u6BCF 24 \u5C0F\u65F6\u540E\u53F0\u81EA\u52A8\u6574\u7406\u4E00\u6B21\uFF1B\u4E0A\u6B21\uFF1A{time}\uFF0C\u5F52\u6863 {n} \u4E2A\u5BF9\u8BDD": "Tidies automatically every 24 hours; last run {time}, {n} sessions archived"
  };
  function syncLocaleFromPage() {
    let next = "";
    try {
      next = globalThis.localStorage?.getItem(PAGE_LOCALE_KEY) || "";
    } catch (error) {
      next = "";
    }
    if (next !== "zh" && next !== "en") {
      next = globalThis.navigator?.language?.toLowerCase().startsWith("zh") ? "zh" : "en";
    }
    const changed = next !== currentLocale;
    currentLocale = next;
    if (changed) {
      try {
        if (typeof chrome !== "undefined" && chrome?.storage?.local) {
          chrome.storage.local.set({ [LOCALE_MIRROR_STORAGE_KEY]: next }).catch(() => {
          });
        }
      } catch (error) {
      }
    }
    return changed;
  }
  function t(text, vars) {
    let zh = text;
    if (text.startsWith("[")) {
      const close = text.indexOf("]");
      if (close > 1) zh = text.slice(close + 1);
    }
    let out = currentLocale === "en" ? EN[text] ?? zh : zh;
    if (vars) {
      for (const [key, value] of Object.entries(vars)) {
        out = out.replaceAll(`{${key}}`, String(value));
      }
    }
    return out;
  }
  function statusText(status) {
    return t(STATUS_TEXT[status] || status);
  }

  // src/content/panel-state.js
  var SESSION_SAMPLE_LIMIT = 50;
  function emptyAgentMetric() {
    return { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 };
  }
  var panel = {
    metrics: {
      inputTokens: 0,
      outputTokens: 0,
      cacheReadTokens: 0,
      cacheCreationTokens: 0,
      lastDuration: 0,
      agentStatus: "idle"
    },
    // 逐 step 样本：{ input, output, cachePct, speed, turnEnd? }，整宽模块的折线图数据源
    sessionSamples: [],
    // 逐轮耗时样本（上轮耗时模块的折线图数据源）
    turnDurations: [],
    // 当前会话按代理的计数器；'main' 为主代理，其余为子代理 id（agent-N）
    agentTotals: { main: emptyAgentMetric() },
    // 子代理显示顺序：按本会话首次出现排序；模型名来自 CLI 扫描的按代理汇总
    sessionAgentOrder: ["main"],
    agentTopModels: {},
    // CLI 配置里的次级模型真名（config.toml [secondary_model]，需授权 .kimi-code 根目录）
    secondaryModelName: "",
    // 正在工作中的子代理（subagent.* 生命周期事件维护）
    activeSubagents: /* @__PURE__ */ new Set(),
    // 模块配置（chrome.storage.local 加载前先用默认值）
    widgetConfig: normalizeWidgetConfig(null),
    // 面板 DOM 引用缓存（cacheElements 重建；渲染层只读）
    els: null,
    // 额度与余额的最近渲染值（结构重建后用于重绘）
    lastQuotaPct: { "5h": null, week: null, month: null },
    quotaResetAt: { "5h": null, week: null, month: null },
    lastWallet: null,
    // 本地 CLI 长期统计缓存与连接状态
    usageDailyCache: {},
    usageHourlyCache: {},
    cliUsageConnected: false,
    // 外部账户最近一次拉取结果
    externalProviders: [],
    // 未授权时状态灯恒红（WS 断开优先显示未连接）
    quotaAuthRequired: false,
    // 本轮回答进行中（pet 域写，渲染层读）
    petTurnActive: false
  };
  function agentDisplayName(agentId) {
    if (agentId === "main") return t("\u4E3B\u4EE3\u7406");
    const index = panel.sessionAgentOrder.indexOf(agentId);
    return index > 0 ? t("\u5B50\u4EE3\u7406 {index}", { index }) : t("\u5B50\u4EE3\u7406");
  }
  function agentModelLabel(agentId) {
    let model = panel.agentTopModels[agentId];
    if (model === "__secondary__" || agentId !== "main" && !model) {
      model = panel.secondaryModelName || "";
    }
    if (!model) return "";
    return String(model).replace(/^kimi-code\//, "").replace(/^kimi-/, "");
  }
  function registerSessionAgent(agentId) {
    if (!panel.agentTotals[agentId]) {
      panel.agentTotals[agentId] = emptyAgentMetric();
      panel.sessionAgentOrder.push(agentId);
    }
  }
  function quotaPollingWanted() {
    const modules = panel.widgetConfig.modules;
    const quotaVisible = ["quota5h", "quotaWeek"].some(
      (id) => modules[id]?.show !== "hidden"
    );
    const balanceVisible = modules.header?.show !== "hidden" && modules.header?.showBalance !== false;
    const petBalanceVisible = modules.pet?.show !== "hidden" && modules.pet?.stat === "balance";
    return quotaVisible || balanceVisible || petBalanceVisible;
  }
  function pushStepSample(payload) {
    const usage = normalizeUsage(payload.usage || payload.token_usage);
    const streamDuration = payload.llmStreamDurationMs ?? payload.llmServerDecodeMs;
    const speed = decodeSpeed(usage.outputTokens, streamDuration);
    const stepInput = totalInputTokens(usage);
    panel.sessionSamples.push({
      input: stepInput,
      output: usage.outputTokens,
      cachePct: stepInput > 0 ? usage.cacheReadTokens / stepInput * 100 : null,
      speed,
      outMs: Number.isFinite(Number(streamDuration)) ? Number(streamDuration) : null
    });
    if (panel.sessionSamples.length > SESSION_SAMPLE_LIMIT) panel.sessionSamples.shift();
  }
  function markLastSampleTurnEnd() {
    const lastSample = panel.sessionSamples[panel.sessionSamples.length - 1];
    if (lastSample) lastSample.turnEnd = true;
  }
  function recordTurnDuration(duration) {
    panel.metrics.lastDuration = duration;
    panel.turnDurations.push(duration);
    if (panel.turnDurations.length > SESSION_SAMPLE_LIMIT) panel.turnDurations.shift();
  }
  function resetMetrics() {
    panel.metrics.inputTokens = 0;
    panel.metrics.outputTokens = 0;
    panel.metrics.cacheReadTokens = 0;
    panel.metrics.cacheCreationTokens = 0;
    panel.metrics.lastDuration = 0;
    panel.metrics.agentStatus = "idle";
    panel.sessionSamples.length = 0;
    panel.turnDurations.length = 0;
    Object.keys(panel.agentTotals).forEach((key) => delete panel.agentTotals[key]);
    Object.assign(panel.agentTotals, { main: emptyAgentMetric() });
    panel.sessionAgentOrder.length = 0;
    panel.sessionAgentOrder.push("main");
    Object.keys(panel.agentTopModels).forEach((key) => delete panel.agentTopModels[key]);
  }

  // src/content/render.js
  var STATUS_MIN_DISPLAY_MS = 1500;
  var CHART_RANGE_DAYS = { day: 1, week: 7, month: 30 };
  var CHART_RANGE_LABELS = { day: "24h\u6D88\u8017", week: "7d\u6D88\u8017", month: "30d\u6D88\u8017" };
  var QUOTA_WINDOW_MS = { "5h": 300 * 6e4, week: 7 * 24 * 36e5 };
  function paceWindowMs(prefix, resetMs) {
    if (prefix === "month" && Number.isFinite(resetMs)) {
      const start2 = new Date(resetMs);
      start2.setMonth(start2.getMonth() - 1);
      return resetMs - start2.getTime();
    }
    return QUOTA_WINDOW_MS[prefix];
  }
  var PACE_MODULE_IDS = { "5h": "quota5h", week: "quotaWeek", month: "quotaMonth" };
  var {
    metrics,
    sessionSamples,
    turnDurations,
    agentTotals,
    sessionAgentOrder,
    activeSubagents
  } = panel;
  var hooks = {
    isDisposed: () => false,
    petUpdateStatus: null,
    roamPetSetStatus: null,
    onQuotaReset: null
  };
  function initRender(nextHooks) {
    hooks = { ...hooks, ...nextHooks };
  }
  function currentSpeed() {
    return aggregateSpeed(sessionSamples);
  }
  function updateProgress(prefix, percentage) {
    const clamped = Math.max(0, Math.min(100, percentage));
    const displayPercentage = formatPercentage(clamped, 0);
    panel.lastQuotaPct[prefix] = clamped;
    const target = panel.els?.quota[prefix];
    if (!target) return;
    const color = progressClass(clamped);
    if (target.fill) {
      target.fill.style.width = `${clamped}%`;
      target.fill.className = `ksb-progress-fill ${color}`;
    }
    if (target.pct) {
      target.pct.textContent = `${displayPercentage}%`;
      target.pct.className = `ksb-quota-pct ${color}`;
    }
  }
  function updateBalance(wallet) {
    if (wallet !== void 0) panel.lastWallet = wallet;
    if (!panel.els?.balance) return;
    const balanceYuan = boosterBalanceYuan(panel.lastWallet);
    panel.els.balance.textContent = balanceYuan != null ? `\xA5${balanceYuan.toFixed(2)}` : t("\u4F59\u989D --");
  }
  function updateTokenDisplay() {
    if (!panel.els) return;
    if (panel.els.inputTokens) panel.els.inputTokens.textContent = formatTokenCount(totalInputTokens(metrics));
    if (panel.els.outputTokens) panel.els.outputTokens.textContent = formatTokenCount(metrics.outputTokens);
  }
  function updateCacheDisplay() {
    if (!panel.els?.cachePct) return;
    const percentage = cacheReadPercentage(metrics);
    panel.els.cachePct.textContent = percentage != null ? `${formatPercentage(percentage)}%` : "--";
  }
  function updatePerfDisplay() {
    if (!panel.els) return;
    if (panel.els.speedVal) {
      const speed = currentSpeed();
      panel.els.speedVal.textContent = speed > 0 ? `${speed}tok/s` : "--";
    }
    if (panel.els.durationSub && panel.els.durationVal) {
      if (metrics.lastDuration > 0) {
        panel.els.durationVal.textContent = fmtDuration(metrics.lastDuration);
        panel.els.durationSub.hidden = false;
      } else {
        panel.els.durationSub.hidden = true;
      }
    }
    if (panel.els.durationValue) {
      panel.els.durationValue.textContent = metrics.lastDuration > 0 ? fmtDuration(metrics.lastDuration) : "--";
    }
  }
  var displayedAgentStatus = "";
  var statusMinUntil = 0;
  var pendingDisplayStatus = null;
  var pendingStatusTimer = null;
  function paintAgentStatus(display) {
    if (!panel.els) return;
    if (panel.els.statusDot) panel.els.statusDot.className = `ksb-status-dot ksb-${display}`;
    if (panel.els.agentStatus) panel.els.agentStatus.textContent = statusText(display);
    hooks.petUpdateStatus?.(display);
    hooks.roamPetSetStatus?.(display);
  }
  function setAgentStatus(status) {
    metrics.agentStatus = status;
    if (!panel.els) return;
    const display = panel.quotaAuthRequired && status !== "offline" ? "unauthorized" : status;
    if (display === displayedAgentStatus) {
      paintAgentStatus(display);
      return;
    }
    const wait = statusMinUntil - Date.now();
    if (wait <= 0) {
      displayedAgentStatus = display;
      statusMinUntil = Date.now() + STATUS_MIN_DISPLAY_MS;
      paintAgentStatus(display);
      return;
    }
    pendingDisplayStatus = display;
    if (!pendingStatusTimer) {
      pendingStatusTimer = setTimeout(() => {
        pendingStatusTimer = null;
        if (hooks.isDisposed()) return;
        const next = pendingDisplayStatus;
        pendingDisplayStatus = null;
        if (next == null || next === displayedAgentStatus) return;
        displayedAgentStatus = next;
        statusMinUntil = Date.now() + STATUS_MIN_DISPLAY_MS;
        paintAgentStatus(next);
      }, wait);
    }
  }
  function renderAll() {
    updateTokenDisplay();
    updateCacheDisplay();
    updatePerfDisplay();
    setAgentStatus(metrics.agentStatus);
    renderSparks();
    renderAgents();
    renderExternal();
    renderPetStats();
  }
  var SPARK_DEFS = {
    input: { values: () => sessionSamples.map((s) => s.input), fmt: (v) => formatTokenCount(v), marks: () => sessionSamples.map((s) => s.turnEnd === true) },
    output: { values: () => sessionSamples.map((s) => s.output), fmt: (v) => formatTokenCount(v), marks: () => sessionSamples.map((s) => s.turnEnd === true) },
    cache: { values: () => sessionSamples.map((s) => s.cachePct), fmt: (v) => `${formatPercentage(v)}%`, marks: () => sessionSamples.map((s) => s.turnEnd === true) },
    speed: { values: () => sessionSamples.map((s) => s.speed), fmt: (v) => `${v}tok/s`, marks: () => sessionSamples.map((s) => s.turnEnd === true) },
    duration: { values: () => turnDurations, fmt: (v) => fmtDuration(v) }
  };
  function renderSparks() {
    if (!panel.els?.sparks) return;
    for (const [id, def] of Object.entries(SPARK_DEFS)) {
      const svg = panel.els.sparks[id];
      sparkRectCache.delete(svg);
      renderSpark(svg, def.values(), def.fmt, def.marks?.());
    }
  }
  var sparkResizeRaf = 0;
  var sparkRectCache = /* @__PURE__ */ new WeakMap();
  var sparkResizeObserver = new ResizeObserver(() => {
    if (sparkResizeRaf) return;
    sparkResizeRaf = requestAnimationFrame(() => {
      sparkResizeRaf = 0;
      renderSparks();
    });
  });
  function renderSpark(svg, values, fmt, marks) {
    if (!svg) return;
    const pairs = values.map((v, i) => ({ v, turn: marks?.[i] === true })).filter((p) => Number.isFinite(p.v));
    if (!pairs.length) {
      svg.replaceChildren();
      return;
    }
    const pts = pairs.map((p) => p.v);
    const max = Math.max(...pts);
    const min = Math.min(0, ...pts);
    const range = max - min || 1;
    const W = 100;
    const H = 28;
    const P = 2;
    const n = pts.length;
    const coords = pts.map((v, i) => {
      const x = n === 1 ? W / 2 : P + i / (n - 1) * (W - 2 * P);
      const y = H - P - (v - min) / range * (H - 2 * P);
      return [x, y];
    });
    let rect = sparkRectCache.get(svg);
    if (!rect || rect.width <= 0 || rect.height <= 0) {
      rect = svg.getBoundingClientRect();
      sparkRectCache.set(svg, rect);
    }
    const kx = rect.width > 0 ? rect.width / W : 1;
    const ky = rect.height > 0 ? rect.height / H : 1;
    const dot = (x, y, r, cls) => `<circle class="${cls}" transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) scale(${(1 / kx).toFixed(4)} ${(1 / ky).toFixed(4)})" r="${r}"/>`;
    const linePoints = coords.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
    const [lastX, lastY] = coords[n - 1];
    const areaPoints = `${P},${H - P} ${linePoints} ${lastX.toFixed(1)},${H - P}`;
    const spacing = n === 1 ? W - 2 * P : (W - 2 * P) / (n - 1);
    const hits = coords.map(([x, y], i) => {
      const fx = x.toFixed(1);
      const rx = Math.max(0, Math.min(W, x - spacing / 2));
      const rw = Math.max(1, Math.min(W, x + spacing / 2) - rx);
      const label = pairs[i].turn ? t("\u7B2C{n}\u6B65 \xB7 \u672C\u8F6E\u7ED3\u675F", { n: i + 1 }) : t("\u7B2C{n}\u6B65", { n: i + 1 });
      return `<g class="ksb-spark-pt"><line class="ksb-spark-pt-line" x1="${fx}" y1="1" x2="${fx}" y2="27" stroke="url(#${svg.id}-linefade)"/>${dot(x, y, 2.6, "ksb-spark-pt-dot")}<rect class="ksb-spark-hit" x="${rx.toFixed(1)}" y="0" width="${rw.toFixed(1)}" height="28" fill="transparent"><title>${escapeHtml(label)} \xB7 ${escapeHtml(fmt(pts[i]))}</title></rect></g>`;
    }).join("");
    const turnDots = coords.map(([x, y], i) => pairs[i].turn ? dot(x, y, 2.2, "ksb-spark-dot") : "").join("");
    svg.innerHTML = `
    <defs>
      <linearGradient id="${svg.id}-vfade" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="currentColor" stop-opacity="1"/>
        <stop offset="1" stop-color="currentColor" stop-opacity="0"/>
      </linearGradient>
      <linearGradient id="${svg.id}-linefade" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="currentColor" stop-opacity="0"/>
        <stop offset="0.15" stop-color="currentColor" stop-opacity="1"/>
        <stop offset="0.85" stop-color="currentColor" stop-opacity="1"/>
        <stop offset="1" stop-color="currentColor" stop-opacity="0"/>
      </linearGradient>
      <linearGradient id="${svg.id}-xfade" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0" stop-color="#ffffff" stop-opacity="0"/>
        <stop offset="0.06" stop-color="#ffffff" stop-opacity="1"/>
        <stop offset="0.94" stop-color="#ffffff" stop-opacity="1"/>
        <stop offset="1" stop-color="#ffffff" stop-opacity="0"/>
      </linearGradient>
      <mask id="${svg.id}-xmask">
        <rect x="0" y="0" width="100" height="28" fill="url(#${svg.id}-xfade)"/>
      </mask>
    </defs>
    <g mask="url(#${svg.id}-xmask)">
      <polygon class="ksb-spark-area" points="${areaPoints}" fill="url(#${svg.id}-vfade)"/>
      <polyline class="ksb-spark-line" points="${linePoints}"/>
    </g>
    ${turnDots}
    ${dot(lastX, lastY, 2.2, "ksb-spark-dot")}
    ${hits}`;
  }
  function renderChart() {
    if (!panel.els?.chartBars || !panel.els.chartTotal) return;
    const module = panel.els.chartBars.closest(".ksb-module");
    module?.classList.toggle("ksb-cli-required", !panel.cliUsageConnected);
    if (panel.els.cliLock) panel.els.cliLock.hidden = panel.cliUsageConnected;
    if (!panel.cliUsageConnected) {
      panel.els.chartTotal.textContent = panel.standaloneMode ? t(STATUS_SHORT[panel.statusLevel] || STATUS_SHORT.loading) : t("\u9700\u8FDE\u63A5");
      if (panel.els.chartHitFull) panel.els.chartHitFull.textContent = "";
      if (panel.els.chartHitShort) panel.els.chartHitShort.textContent = "";
      panel.els.chartBars.replaceChildren();
      return;
    }
    const range = panel.widgetConfig.modules.usageChart?.chartRange || "week";
    const days = CHART_RANGE_DAYS[range] || 7;
    const endKey = usageDayKey(/* @__PURE__ */ new Date());
    const startDate = /* @__PURE__ */ new Date();
    startDate.setDate(startDate.getDate() - (days - 1));
    const startKey = usageDayKey(startDate);
    if (panel.els.chartLabel) panel.els.chartLabel.textContent = t(CHART_RANGE_LABELS[range] || CHART_RANGE_LABELS.week);
    panel.els.chartBars.replaceChildren();
    let sum;
    let columns;
    if (range === "day") {
      columns = [];
      sum = { totalTokens: 0, cacheHitRate: null };
      let input = 0;
      let cacheRead = 0;
      for (let i = 23; i >= 0; i -= 1) {
        const key = usageHourKey(new Date(Date.now() - i * 36e5));
        const bucket = panel.usageHourlyCache[key];
        const tokens = bucket ? bucket.input + bucket.output : 0;
        columns.push({
          label: `${key.slice(5, 10)} ${key.slice(11)}:00`,
          tokens,
          subTokens: bucket?.sub ? bucket.sub.input + bucket.sub.output : 0
        });
        input += bucket?.input || 0;
        cacheRead += bucket?.cacheRead || 0;
        sum.totalTokens += tokens;
      }
      sum.cacheHitRate = input > 0 ? cacheRead / input : null;
    } else {
      sum = sumUsageBetween(panel.usageDailyCache, startKey, endKey);
      columns = listDayKeysBetween(startKey, endKey).map((key) => {
        const bucket = panel.usageDailyCache[key];
        return {
          label: key.slice(5),
          tokens: bucket ? bucket.input + bucket.output : 0,
          subTokens: bucket?.sub ? bucket.sub.input + bucket.sub.output : 0
        };
      });
    }
    panel.els.chartTotal.textContent = sum.totalTokens > 0 ? formatTokenCount(sum.totalTokens) : "--";
    const hitPct = sum.cacheHitRate != null ? `${formatPercentage(sum.cacheHitRate * 100)}%` : "";
    if (panel.els.chartHitFull) panel.els.chartHitFull.textContent = hitPct ? t("\u7F13\u5B58\u547D\u4E2D {pct}", { pct: hitPct }) : "";
    if (panel.els.chartHitShort) panel.els.chartHitShort.textContent = hitPct;
    const maxTokens = Math.max(0, ...columns.map((c) => c.tokens));
    for (const { label, tokens, subTokens } of columns) {
      const mainTokens = tokens - subTokens;
      const col = document.createElement("span");
      col.className = "ksb-chart-col";
      col.title = subTokens > 0 ? t("{date} \xB7 \u4E3B {main} \xB7 \u5B50 {sub}", { date: label, main: formatTokenCount(mainTokens), sub: formatTokenCount(subTokens) }) : `${label} \xB7 ${formatTokenCount(tokens)}`;
      const stack = document.createElement("span");
      stack.className = "ksb-chart-stack";
      if (subTokens > 0 && maxTokens > 0) {
        const subBar = document.createElement("span");
        subBar.className = "ksb-chart-bar sub";
        subBar.style.height = `${subTokens / maxTokens * 100}%`;
        stack.append(subBar);
      }
      const mainBar = document.createElement("span");
      mainBar.className = subTokens > 0 ? "ksb-chart-bar flat" : "ksb-chart-bar";
      mainBar.style.height = `${Math.max(8, maxTokens > 0 ? mainTokens / maxTokens * 100 : 8)}%`;
      stack.append(mainBar);
      col.append(stack);
      panel.els.chartBars.append(col);
    }
  }
  function renderAgents() {
    if (!panel.els?.agentsList) return;
    const hiddenAgents = panel.widgetConfig.modules.agents?.hiddenAgents || [];
    const mainWorking = panel.petTurnActive || PET_ANSWER_STATUSES.includes(metrics.agentStatus);
    const groups = /* @__PURE__ */ new Map();
    for (const agentId of sessionAgentOrder) {
      if (agentId === "main" || hiddenAgents.includes(agentId)) continue;
      const totals = agentTotals[agentId];
      if (!totals) continue;
      const key = agentModelLabel(agentId);
      let group = groups.get(key);
      if (!group) {
        group = { ...emptyAgentMetric(), working: false, count: 0 };
        groups.set(key, group);
      }
      group.inputTokens += totals.inputTokens;
      group.outputTokens += totals.outputTokens;
      group.cacheReadTokens += totals.cacheReadTokens;
      group.cacheCreationTokens += totals.cacheCreationTokens;
      group.working = group.working || activeSubagents.has(agentId);
      group.count += 1;
    }
    const rows = [];
    const pushRow = ({ isMain, totals, working, name, title }) => {
      const hasUsage = totalInputTokens(totals) > 0 || totals.outputTokens > 0;
      if (!hasUsage && !working && !isMain) return;
      const hit = cacheReadPercentage(totals);
      const badge = isMain ? `<span class="ksb-agent-badge main${working ? " on" : ""}">\u4E3B</span>` : `<span class="ksb-agent-badge sub${working ? " on" : ""}">\u5B50</span>`;
      rows.push(`
      <div class="ksb-agent-row${isMain ? " main" : ""}" title="${escapeHtml(title)}">
        <span class="ksb-agent-id">${badge}</span>
        <span class="ksb-agent-model">${escapeHtml(name)}</span>
        <span class="ksb-agent-metric m-in">${formatTokenCount(totalInputTokens(totals))}</span>
        <span class="ksb-agent-metric m-out">${formatTokenCount(totals.outputTokens)}</span>
        <span class="ksb-agent-metric m-hit">${hit != null ? `${formatPercentage(hit)}%` : "--"}</span>
      </div>`);
    };
    const mainModel = agentModelLabel("main");
    pushRow({
      isMain: true,
      totals: agentTotals.main || emptyAgentMetric(),
      working: mainWorking,
      name: escapeHtml(mainModel),
      title: `${t("\u4E3B\u4EE3\u7406")}${mainModel ? ` \xB7 ${mainModel}` : ""}`
    });
    for (const [model, group] of groups) {
      pushRow({
        isMain: false,
        totals: group,
        working: group.working,
        // 模型名缺失（未授权 CLI 读不到次级模型名）时兜底为「子代理」，避免裸 ×N
        name: escapeHtml(`${model || t("\u5B50\u4EE3\u7406")}${group.count > 1 ? ` \xD7${group.count}` : ""}`),
        title: `${t("\u5B50\u4EE3\u7406")}${model ? ` \xB7 ${model}` : ""}${group.count > 1 ? ` \xD7${group.count}` : ""}`
      });
    }
    panel.els.agentsList.innerHTML = rows.join("");
  }
  function formatExternalValue(provider) {
    if (provider.error) return { main: t("\u83B7\u53D6\u5931\u8D25"), sub: "", note: provider.error };
    if (provider.kind === "balance") {
      const main = `${provider.currency}${provider.total.toFixed(2)}`;
      return {
        main,
        sub: "",
        note: t("\u8D60\u9001 {granted} \xB7 \u5145\u503C {paid}", { granted: `${provider.currency}${provider.granted.toFixed(2)}`, paid: `${provider.currency}${provider.paid.toFixed(2)}` })
      };
    }
    if (provider.windows?.length) {
      const [first, second] = provider.windows;
      const reset = provider.windows.find((w) => w.resetAt)?.resetAt;
      return {
        main: `${formatPercentage(first.pct)}%`,
        sub: second ? `${second.label} ${formatPercentage(second.pct)}%` : "",
        note: [provider.plan, reset ? t("\u91CD\u7F6E {time}", { time: new Date(reset).toLocaleString() }) : ""].filter(Boolean).join(" \xB7 ")
      };
    }
    return { main: provider.plan || t("\u5DF2\u542F\u7528"), sub: "", note: "" };
  }
  function renderExternal() {
    const hiddenAccounts = panel.widgetConfig.modules.external?.hiddenAccounts || [];
    const visible = panel.externalProviders.filter((p) => !hiddenAccounts.includes(p.id));
    if (panel.els?.externalTitle) {
      const first = visible[0];
      panel.els.externalTitle.textContent = first ? first.name : t("\u5916\u90E8\u8D26\u6237");
      if (!first) {
        panel.els.externalValue.textContent = "--";
        panel.els.externalSub.hidden = true;
      } else {
        const formatted = formatExternalValue(first);
        panel.els.externalValue.textContent = formatted.main;
        panel.els.externalSub.textContent = formatted.sub;
        panel.els.externalSub.hidden = !formatted.sub;
      }
    }
    if (!panel.els?.externalList) return;
    if (!visible.length) {
      panel.els.externalList.innerHTML = `<div class="ksb-external-empty">${t(panel.standaloneMode ? "\u4F7F\u7528 kimi-code-monitor \u6280\u80FD\uFF0C\u8BA9 Kimi \u914D\u7F6E\u5916\u90E8\u8D26\u6237" : "\u5728\u6269\u5C55\u5F39\u7A97\u4E2D\u914D\u7F6E API Key")}</div>`;
      return;
    }
    const nameCounts = {};
    for (const p of visible) nameCounts[p.name] = (nameCounts[p.name] || 0) + 1;
    const valueHtml = (provider) => {
      if (provider.error) return t("\u83B7\u53D6\u5931\u8D25");
      if (provider.kind === "balance") {
        return `<span class="ksb-external-kind">${t("API\u4F59\u989D")}</span> ${escapeHtml(provider.currency)}${provider.total.toFixed(2)}`;
      }
      if (provider.windows?.length) {
        return provider.windows.map((w) => `<span class="ksb-external-kind">${escapeHtml(w.label)}</span> ${formatPercentage(w.pct)}%`).join(" \xB7 ");
      }
      return provider.plan ? escapeHtml(provider.plan) : t("\u5DF2\u542F\u7528");
    };
    panel.els.externalList.innerHTML = visible.map((provider) => {
      const label = nameCounts[provider.name] > 1 ? `${escapeHtml(provider.name)} \xB7${escapeHtml(provider.keyTail)}` : escapeHtml(provider.name);
      const formatted = formatExternalValue(provider);
      return `
        <div class="ksb-external-row" title="${label}${formatted.note ? ` \xB7 ${escapeHtml(formatted.note)}` : ""}">
          <span class="ksb-external-name">${label}</span>
          <span class="ksb-external-value${provider.error ? " err" : ""}">${valueHtml(provider)}</span>
        </div>`;
    }).join("");
  }
  var PET_STAT_DEFS = {
    daily: {
      label: "\u4ECA\u65E5\u6D88\u8017",
      value: () => {
        if (!panel.cliUsageConnected) {
          return panel.standaloneMode ? t(STATUS_SHORT[panel.statusLevel] || STATUS_SHORT.loading) : t("\u9700\u8FDE\u63A5 CLI");
        }
        const bucket = panel.usageDailyCache[usageDayKey(/* @__PURE__ */ new Date())];
        const total = bucket ? bucket.input + bucket.output : 0;
        return total > 0 ? formatTokenCount(total) : "--";
      }
    },
    input: { label: "\u8F93\u5165", value: () => formatTokenCount(totalInputTokens(metrics)) },
    output: { label: "\u8F93\u51FA", value: () => formatTokenCount(metrics.outputTokens) },
    cache: {
      label: "\u7F13\u5B58\u547D\u4E2D",
      value: () => {
        const pct = cacheReadPercentage(metrics);
        return pct != null ? `${formatPercentage(pct)}%` : "--";
      }
    },
    speed: {
      label: "\u901F\u5EA6",
      value: () => {
        const speed = currentSpeed();
        return speed > 0 ? `${speed}tok/s` : "--";
      }
    },
    balance: {
      label: "\u4F59\u989D",
      value: () => {
        const yuan = boosterBalanceYuan(panel.lastWallet);
        return yuan != null ? `\xA5${yuan.toFixed(2)}` : "--";
      }
    }
  };
  function renderPetStats() {
    if (!panel.els?.petTotal) return;
    const def = PET_STAT_DEFS[panel.widgetConfig.modules.pet?.stat] || PET_STAT_DEFS.daily;
    if (panel.els.petLabel) panel.els.petLabel.textContent = t(def.label);
    panel.els.petTotal.textContent = def.value();
  }
  function fmtCountdown(diffMs) {
    const totalMin = Math.floor(diffMs / 6e4);
    if (totalMin < 1) return t("\u5373\u5C06\u91CD\u7F6E");
    const hours = Math.floor(totalMin / 60);
    const minutes = totalMin % 60;
    if (hours < 1) return `${totalMin}m`;
    const days = Math.floor(hours / 24);
    const restHours = hours % 24;
    if (days >= 1) return `${days}d${restHours ? `${restHours}h` : ""}`;
    return `${hours}h${minutes ? `${minutes}m` : ""}`;
  }
  function fmtCountdownShort(diffMs) {
    const totalMin = Math.floor(diffMs / 6e4);
    if (totalMin < 1) return t("\u5373\u5C06\u91CD\u7F6E");
    const hours = Math.floor(totalMin / 60);
    if (hours < 1) return `${totalMin}m`;
    const days = Math.floor(hours / 24);
    if (days >= 1) return `${days}d`;
    return `${hours}h`;
  }
  function fmtCountdownLong(diffMs, resetMs) {
    const totalMin = Math.floor(diffMs / 6e4);
    const date = new Date(resetMs);
    const abs = `${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
    if (totalMin < 1) return t("\u5373\u5C06\u91CD\u7F6E");
    const hours = Math.floor(totalMin / 60);
    const minutes = totalMin % 60;
    const days = Math.floor(hours / 24);
    const text = days >= 1 ? t("{days}\u5929{hours}\u5C0F\u65F6\u540E\u91CD\u7F6E", { days, hours: hours % 24 }) : hours >= 1 ? t("{hours}\u5C0F\u65F6{minutes}\u5206\u949F\u540E\u91CD\u7F6E", { hours, minutes }) : t("{totalMin}\u5206\u949F\u540E\u91CD\u7F6E", { totalMin });
    return `${text}\uFF08${abs}\uFF09`;
  }
  var RESET_WEEKDAYS = [t("\u5468\u65E5"), t("\u5468\u4E00"), t("\u5468\u4E8C"), t("\u5468\u4E09"), t("\u5468\u56DB"), t("\u5468\u4E94"), t("\u5468\u516D")];
  function fmtResetAbsolute(resetMs, { short = false } = {}) {
    const date = new Date(resetMs);
    const now = /* @__PURE__ */ new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const time = `${pad(date.getHours())}:${pad(date.getMinutes())}`;
    const sameDay = date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth() && date.getDate() === now.getDate();
    if (sameDay) return time;
    const weekday = RESET_WEEKDAYS[date.getDay()];
    return short ? weekday : `${weekday}${time}`;
  }
  var resetRefetchTimer = null;
  function updateResetText(prefix, resetMs) {
    panel.quotaResetAt[prefix] = resetMs;
    updatePaceTick(prefix);
    const element = panel.els?.quota[prefix]?.reset;
    if (!element) return;
    const full = element.querySelector(".ksb-reset-full");
    const short = element.querySelector(".ksb-reset-short");
    const useAbsolute = panel.widgetConfig.modules[PACE_MODULE_IDS[prefix]]?.resetFormat === "absolute";
    element.classList.toggle("ksb-abs", useAbsolute);
    if (!Number.isFinite(resetMs)) {
      if (full) full.textContent = "";
      if (short) short.textContent = "";
      setResetTooltip(prefix, "");
      return;
    }
    const diff = resetMs - Date.now();
    if (full) {
      full.textContent = diff > 0 ? useAbsolute ? fmtResetAbsolute(resetMs) : fmtCountdown(diff) : t("\u5373\u5C06\u91CD\u7F6E");
    }
    if (short) {
      short.textContent = diff > 0 ? useAbsolute ? fmtResetAbsolute(resetMs, { short: true }) : fmtCountdownShort(diff) : t("\u5373\u5C06\u91CD\u7F6E");
    }
    setResetTooltip(prefix, fmtCountdownLong(Math.max(diff, 0), resetMs));
    if (diff <= 0 && !resetRefetchTimer) {
      resetRefetchTimer = setTimeout(() => {
        resetRefetchTimer = null;
        hooks.onQuotaReset?.();
      }, 15e3);
    }
  }
  function updatePaceTick(prefix) {
    const tick = panel.els?.quota[prefix]?.pace;
    if (!tick) return;
    if (panel.widgetConfig.modules[PACE_MODULE_IDS[prefix]]?.pace === false) {
      tick.hidden = true;
      return;
    }
    const resetMs = panel.quotaResetAt[prefix];
    const windowMs = paceWindowMs(prefix, resetMs);
    const diff = Number.isFinite(resetMs) ? resetMs - Date.now() : NaN;
    if (!Number.isFinite(diff) || !Number.isFinite(windowMs) || diff > windowMs) {
      tick.hidden = true;
      return;
    }
    const elapsed = Math.max(0, Math.min(1, 1 - diff / windowMs));
    tick.style.left = `${elapsed * 100}%`;
    tick.hidden = false;
  }
  function setResetTooltip(prefix, text) {
    const group = panel.els?.quota[prefix]?.pct?.closest(".ksb-quota-group");
    if (group) group.title = text;
  }

  // src/content/pet-panel.js
  var PET_RIV_URL = chrome.runtime.getURL("rive/kimi_avatar_web-PnsTWI-X.riv");
  var PET_WASM_URL = chrome.runtime.getURL("rive/rive.wasm");
  var PET_IDLE_ANIM = "paopao";
  var PET_LOADING_ANIM = "loading";
  var PET_DONE_ANIM = "stars";
  var PET_DONE_OUTRO_ANIM = "nostars";
  var PET_CLICK_ANIMS = [
    "yaoyiyao",
    "angryface",
    "wink",
    "angryeye",
    "hover",
    "hover100",
    "wink_stop",
    "paopao_stop"
  ];
  var PET_TOGGLE_ANIMS = [
    "yaoyiyao",
    "angryface",
    "wink",
    "angryeye",
    "hover",
    "hover100"
  ];
  var PET_IDLE_AMBIENT_ANIMS = ["wink", "look_right_stop"];
  var PET_IDLE_AMBIENT_MIN_MS = 8e3;
  var PET_IDLE_AMBIENT_JITTER_MS = 1e4;
  var petRive = null;
  var petCanvasEl = null;
  var petClickBoundCanvas = null;
  var petStatus = "idle";
  var petMotion = "";
  var petStarsVisible = false;
  var petSwitchingMotion = false;
  var petReturnToBase = false;
  var petIdleAmbientTimer = null;
  var petTurnSessionId = "";
  var petTurnSince = 0;
  var petStatusSince = Date.now();
  var petClockTimer = null;
  var PET_CLOCK_STATUSES = ["thinking", "executing", "replying", "subagent", "ratelimit"];
  var deps = {
    isDisposed: () => false,
    getSessionId: () => ""
  };
  function initPet(nextDeps) {
    deps = { ...deps, ...nextDeps };
  }
  function petClockStart() {
    if (petClockTimer) return;
    petClockTimer = setInterval(petClockTick, 1e3);
    petClockTick();
  }
  function petClockTick() {
    if (!panel.els?.petClock || !panel.els.petClockNum) return;
    const pad = (n) => String(n).padStart(2, "0");
    if (!PET_CLOCK_STATUSES.includes(petStatus)) {
      const now = /* @__PURE__ */ new Date();
      const hours = now.getHours();
      const h12 = hours % 12 === 0 ? 12 : hours % 12;
      panel.els.petClock.hidden = false;
      panel.els.petClockNum.textContent = `${h12}:${pad(now.getMinutes())}`;
      if (panel.els.petAmpm) panel.els.petAmpm.textContent = hours < 12 ? "AM" : "PM";
      return;
    }
    const seconds = Math.floor((Date.now() - petStatusSince) / 1e3);
    const s = seconds % 60;
    const m = Math.floor(seconds / 60) % 60;
    const h = Math.floor(seconds / 3600);
    panel.els.petClock.hidden = false;
    panel.els.petClockNum.textContent = h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
    if (panel.els.petAmpm) panel.els.petAmpm.textContent = "";
  }
  function petAppearanceForStatus(status) {
    if (status === "offline" || status === "unauthorized") return "gray";
    if (status === "ratelimit") return "red";
    return "blue";
  }
  function petApplyAppearance() {
    if (!panel.els?.petCanvas) return;
    panel.els.petCanvas.dataset.appearance = petAppearanceForStatus(petStatus);
  }
  function petClearIdleAmbient() {
    if (petIdleAmbientTimer) clearTimeout(petIdleAmbientTimer);
    petIdleAmbientTimer = null;
  }
  function petScheduleIdleAmbient() {
    petClearIdleAmbient();
    if (petStatus !== "idle" || !petRive) return;
    const delay = PET_IDLE_AMBIENT_MIN_MS + Math.random() * PET_IDLE_AMBIENT_JITTER_MS;
    petIdleAmbientTimer = setTimeout(() => {
      petIdleAmbientTimer = null;
      if (deps.isDisposed()) return;
      if (petStatus !== "idle" || petMotion !== PET_IDLE_ANIM || !petRive) {
        petScheduleIdleAmbient();
        return;
      }
      const name = PET_IDLE_AMBIENT_ANIMS[Math.floor(Math.random() * PET_IDLE_AMBIENT_ANIMS.length)];
      petPlayMotion(name, { returnToBase: true });
    }, delay);
  }
  function petPlayMotion(name, { returnToBase = false } = {}) {
    if (!petRive) return;
    petClearIdleAmbient();
    try {
      petSwitchingMotion = true;
      petReturnToBase = returnToBase;
      petRive.stop();
      petRive.play(name);
      petMotion = name;
      if (name === PET_IDLE_ANIM) petScheduleIdleAmbient();
    } catch (error) {
      console.warn("[Kimi Status] \u5409\u7965\u7269\u52A8\u753B\u5207\u6362\u5931\u8D25", error);
    } finally {
      petSwitchingMotion = false;
    }
  }
  function petBaseMotion() {
    return PET_ANSWER_STATUSES.includes(petStatus) ? PET_LOADING_ANIM : PET_IDLE_ANIM;
  }
  function petPlayBase() {
    if (petStarsVisible && petMotion !== PET_DONE_OUTRO_ANIM) {
      petPlayMotion(PET_DONE_OUTRO_ANIM, { returnToBase: true });
      return;
    }
    const desired = petBaseMotion();
    if (petMotion === desired && petRive?.playingAnimationNames?.includes(desired)) return;
    petPlayMotion(desired);
  }
  function petSyncState() {
    petApplyAppearance();
    petPlayBase();
  }
  function petBeginTurn() {
    petTurnSessionId = deps.getSessionId();
    panel.petTurnActive = Boolean(deps.getSessionId());
    petTurnSince = Date.now();
  }
  function petCancelTurn() {
    petTurnSessionId = "";
    panel.petTurnActive = false;
    petTurnSince = 0;
  }
  function petCompleteTurn() {
    const shouldCelebrate = panel.petTurnActive && petTurnSessionId === deps.getSessionId() && Date.now() - petTurnSince > 1e3;
    petCancelTurn();
    if (shouldCelebrate) petPlayDoneEffect();
  }
  function petHandleClick() {
    const name = PET_CLICK_ANIMS[Math.floor(Math.random() * PET_CLICK_ANIMS.length)];
    petPlayMotion(name, { returnToBase: true });
  }
  function petHandleToggle() {
    const name = PET_TOGGLE_ANIMS[Math.floor(Math.random() * PET_TOGGLE_ANIMS.length)];
    petPlayMotion(name, { returnToBase: true });
  }
  function petPlayDoneEffect() {
    if (!petRive || petMotion === PET_DONE_ANIM) return;
    petStarsVisible = true;
    petPlayMotion(PET_DONE_ANIM, { returnToBase: true });
  }
  function petSyncRendering() {
    if (!petRive) return;
    const petInMini = panel.widgetConfig.orderMini.includes("pet");
    const collapsed = Boolean(panel.els?.widget?.classList.contains("ksb-mini")) && !petInMini;
    try {
      if (collapsed) petRive.stopRendering();
      else petRive.startRendering();
    } catch (error) {
    }
  }
  function petStart() {
    const api = globalThis.rive;
    if (!api?.Rive || !api?.RuntimeLoader) return;
    if (petRive && panel.els?.petCanvas && panel.els.petCanvas === petCanvasEl) return;
    if (petRive) {
      try {
        petRive.cleanup();
      } catch (error) {
      }
      petRive = null;
      petCanvasEl = null;
      petMotion = "";
      petStarsVisible = false;
      petSwitchingMotion = false;
      petReturnToBase = false;
      petClearIdleAmbient();
    }
    if (!panel.els?.petCanvas) return;
    api.RuntimeLoader.setWasmUrl(PET_WASM_URL);
    api.RuntimeLoader.setWasmFallbackUrl(null);
    const instance = new api.Rive({
      src: PET_RIV_URL,
      canvas: panel.els.petCanvas,
      autoplay: false,
      fit: api.Fit?.Contain,
      alignment: api.Alignment?.Center,
      onLoad: () => {
        if (petRive !== instance) return;
        petSyncState();
      },
      onStop: (event) => {
        if (petRive !== instance || petSwitchingMotion) return;
        const stopped = Array.isArray(event?.data) ? event.data : [];
        if (!stopped.includes(petMotion)) return;
        queueMicrotask(() => {
          if (petRive !== instance || petSwitchingMotion) return;
          if (petMotion === PET_LOADING_ANIM && PET_ANSWER_STATUSES.includes(petStatus)) {
            petPlayMotion(PET_LOADING_ANIM);
            return;
          }
          if (petMotion === PET_DONE_OUTRO_ANIM) petStarsVisible = false;
          if (petReturnToBase) {
            petReturnToBase = false;
            petPlayBase();
          }
        });
      },
      onLoadError: (error) => console.warn("[Kimi Status] \u5409\u7965\u7269\u52A8\u753B\u52A0\u8F7D\u5931\u8D25", error)
    });
    petRive = instance;
    petCanvasEl = panel.els.petCanvas;
    petApplyAppearance();
    petSyncRendering();
    petClockStart();
    if (petClickBoundCanvas !== panel.els.petCanvas) {
      panel.els.petCanvas.addEventListener("click", (event) => {
        event.stopPropagation();
        petHandleClick();
        const link = panel.widgetConfig.modules.pet?.ballLink;
        if (link === "console" || link === "subscription") {
          window.open(link === "console" ? CONSOLE_URL : SUBSCRIPTION_URL, "_blank");
        }
      });
      petClickBoundCanvas = panel.els.petCanvas;
    }
  }
  function petUpdateStatus(display) {
    if (panel.els?.petStatusText) {
      panel.els.petStatusText.textContent = statusText(display);
      panel.els.petStatus.dataset.status = display;
    }
    if (display === petStatus) {
      petApplyAppearance();
      return;
    }
    const previous = petStatus;
    petStatus = display;
    if (PET_ANSWER_STATUSES.includes(display) && !PET_ANSWER_STATUSES.includes(previous)) {
      petStatusSince = Date.now();
    } else if (!PET_ANSWER_STATUSES.includes(display)) {
      petStatusSince = Date.now();
    }
    petClockTick();
    petSyncState();
  }

  // src/panel-app/bridge.js
  var TOOL_STATUS_MIN_MS = 1500;
  var DEFAULT_SESSION_ID = "panel";
  var STATUS_MAP = {
    idle: "idle",
    working: "thinking",
    waiting: "idle",
    offline: "offline"
  };
  var currentSessionId = DEFAULT_SESSION_ID;
  var activeToolCalls = 0;
  var toolStatusUntil = 0;
  var toolStatusTimer = null;
  var deferredWorkStatus = "thinking";
  function getSessionId() {
    return currentSessionId;
  }
  function setAgentWorkStatus(status) {
    deferredWorkStatus = status;
    if (activeToolCalls > 0 || Date.now() < toolStatusUntil) {
      setAgentStatus("executing");
      return;
    }
    setAgentStatus(status);
  }
  function clearToolStatus() {
    activeToolCalls = 0;
    toolStatusUntil = 0;
    deferredWorkStatus = "thinking";
    if (toolStatusTimer) clearTimeout(toolStatusTimer);
    toolStatusTimer = null;
  }
  function beginToolStatus() {
    activeToolCalls += 1;
    toolStatusUntil = Math.max(toolStatusUntil, Date.now() + TOOL_STATUS_MIN_MS);
    if (toolStatusTimer) clearTimeout(toolStatusTimer);
    toolStatusTimer = null;
    setAgentStatus("executing");
  }
  function finishToolStatus() {
    activeToolCalls = Math.max(0, activeToolCalls - 1);
    if (activeToolCalls > 0) {
      setAgentStatus("executing");
      return;
    }
    const remaining = toolStatusUntil - Date.now();
    if (remaining <= 0) {
      toolStatusUntil = 0;
      setAgentStatus(deferredWorkStatus);
      return;
    }
    if (toolStatusTimer) clearTimeout(toolStatusTimer);
    toolStatusTimer = setTimeout(() => {
      toolStatusTimer = null;
      toolStatusUntil = 0;
      if (activeToolCalls === 0) setAgentStatus(deferredWorkStatus);
    }, remaining);
  }
  function isSubagentEvent(message, payload) {
    const id = message.agent_id ?? payload.agent_id ?? payload.agentId ?? payload.subagentId;
    return Boolean(id) && id !== "main";
  }
  function eventAgentId(message, payload) {
    return message.agent_id ?? payload.agent_id ?? payload.agentId ?? payload.subagentId ?? "main";
  }
  function handleStepCompleted(payload, agentId) {
    const usage = normalizeUsage(payload.usage || payload.token_usage);
    panel.metrics.inputTokens += usage.inputTokens;
    panel.metrics.outputTokens += usage.outputTokens;
    panel.metrics.cacheReadTokens += usage.cacheReadTokens;
    panel.metrics.cacheCreationTokens += usage.cacheCreationTokens;
    noteStepUsage(usage);
    registerSessionAgent(agentId);
    const totals = panel.agentTotals[agentId];
    totals.inputTokens += usage.inputTokens;
    totals.outputTokens += usage.outputTokens;
    totals.cacheReadTokens += usage.cacheReadTokens;
    totals.cacheCreationTokens += usage.cacheCreationTokens;
    pushStepSample(payload);
    renderAll();
  }
  function handleAgentStatusEvent(payload) {
    const status = payload.status || payload.agent_status;
    if (status === "idle" || status === "waiting") {
      setAgentWorkStatus("idle");
      return;
    }
    if (!panel.petTurnActive) return;
    if (status === "thinking" || status === "processing" || status === "running" || status === "working") {
      setAgentWorkStatus("thinking");
    }
  }
  function handleEvent(message) {
    if (!message || typeof message !== "object") return;
    if (message.session_id && message.session_id !== currentSessionId) return;
    const payload = message.payload && typeof message.payload === "object" ? message.payload : message;
    switch (message.type) {
      case "turn.started":
        clearToolStatus();
        petBeginTurn();
        setAgentStatus("thinking");
        break;
      case "turn.step.started":
        setAgentWorkStatus(isSubagentEvent(message, payload) ? "subagent" : "thinking");
        break;
      case "turn.step.completed":
        handleStepCompleted(payload, eventAgentId(message, payload));
        setAgentWorkStatus(isSubagentEvent(message, payload) ? "subagent" : "thinking");
        break;
      case "thinking.delta":
        if (!isSubagentEvent(message, payload) && deferredWorkStatus !== "thinking") {
          setAgentWorkStatus("thinking");
        }
        break;
      case "assistant.delta":
        if (!isSubagentEvent(message, payload) && deferredWorkStatus !== "replying") {
          setAgentWorkStatus("replying");
        }
        break;
      case "subagent.spawned":
      case "subagent.started":
      case "subagent.suspended": {
        const subId = payload.subagentId ?? payload.agentId;
        if (subId) {
          registerSessionAgent(String(subId));
          panel.activeSubagents.add(String(subId));
        }
        setAgentWorkStatus("subagent");
        break;
      }
      case "subagent.completed":
      case "subagent.failed": {
        const subId = payload.subagentId ?? payload.agentId;
        if (subId) panel.activeSubagents.delete(String(subId));
        setAgentWorkStatus("thinking");
        break;
      }
      case "tool.call.started":
        beginToolStatus();
        break;
      case "tool.result":
        finishToolStatus();
        break;
      case "turn.ended":
      case "turn.completed": {
        const duration = Number(payload.durationMs ?? payload.duration_ms ?? payload.duration);
        if (Number.isFinite(duration) && duration > 0) recordTurnDuration(duration);
        clearToolStatus();
        setAgentStatus("idle");
        markLastSampleTurnEnd();
        petCompleteTurn();
        renderAll();
        break;
      }
      case "event.session.work_changed": {
        const busy = Boolean(payload.busy || payload.main_turn_active);
        if (busy && !panel.petTurnActive) break;
        setAgentWorkStatus(busy ? "thinking" : "idle");
        break;
      }
      case "agent.status.updated":
        handleAgentStatusEvent(payload);
        break;
      case "error":
        if (payload?.code === "provider.rate_limit") setAgentStatus("ratelimit");
        break;
      default:
        break;
    }
  }
  function handleQuota(msg) {
    const quota = msg.quota || {};
    const fiveHour = quota.limit5h || quota["5h"];
    const week = quota.limit7d || quota.limitWeek || quota.week;
    if (fiveHour) {
      const ratio = Number(fiveHour.usedRatio);
      if (Number.isFinite(ratio)) updateProgress("5h", ratio * 100);
      updateResetText("5h", parseResetTime(fiveHour.resetAt));
    }
    if (week) {
      const ratio = Number(week.usedRatio);
      if (Number.isFinite(ratio)) updateProgress("week", ratio * 100);
      updateResetText("week", parseResetTime(week.resetAt));
    }
    updateBalance(quota.wallet ?? null);
  }
  var lastFileDaily = {};
  function handleUsageDaily(msg) {
    lastFileDaily = msg.daily && typeof msg.daily === "object" ? msg.daily : {};
    panel.usageHourlyCache = msg.hourly && typeof msg.hourly === "object" ? msg.hourly : {};
    panel.secondaryModelName = typeof msg.secondaryModel === "string" ? msg.secondaryModel : "";
    panel.cliUsageConnected = msg.connected !== false;
    try {
      globalThis.__kcmDebug = { ...globalThis.__kcmDebug, usageDailyOk: true };
    } catch (error) {
    }
    refreshDailyChart();
  }
  function refreshDailyChart() {
    const merged = mergeDaily(lastFileDaily);
    panel.usageDailyCache = merged;
    if (Object.keys(merged).length > 0) panel.cliUsageConnected = true;
    renderChart();
    renderAgents();
    renderPetStats();
  }
  function handleStatus(msg) {
    if (typeof msg.sessionId === "string" && msg.sessionId) currentSessionId = msg.sessionId;
    setAgentStatus(STATUS_MAP[msg.status] || "idle");
  }
  function handleSessionSwitch(msg) {
    const sid = typeof msg.sid === "string" ? msg.sid : "";
    if (!sid || sid === currentSessionId) return;
    currentSessionId = sid;
    resetMetrics();
    clearToolStatus();
    const usage = normalizeUsage(msg.snapshot?.usage || msg.snapshot?.total);
    if (usage) {
      panel.metrics.inputTokens = usage.inputTokens;
      panel.metrics.outputTokens = usage.outputTokens;
      panel.metrics.cacheReadTokens = usage.cacheReadTokens;
      panel.metrics.cacheCreationTokens = usage.cacheCreationTokens;
      registerSessionAgent("main");
      panel.agentTotals.main.inputTokens = usage.inputTokens;
      panel.agentTotals.main.outputTokens = usage.outputTokens;
      panel.agentTotals.main.cacheReadTokens = usage.cacheReadTokens;
      panel.agentTotals.main.cacheCreationTokens = usage.cacheCreationTokens;
    }
    setAgentStatus("idle");
    renderAll();
    renderPetStats();
  }
  function handleExternal(msg) {
    panel.externalProviders = Array.isArray(msg.providers) ? msg.providers : [];
    renderExternal();
  }
  function dispatch(msg) {
    if (!msg || typeof msg !== "object") return;
    if (msg.v != null && msg.v !== 1) {
      console.warn("[Kimi Status] \u5FFD\u7565\u672A\u77E5\u7248\u672C\u7684\u63A8\u9001\u6D88\u606F", msg);
      return;
    }
    if (typeof msg.sessionId === "string" && msg.sessionId) currentSessionId = msg.sessionId;
    switch (msg.type) {
      case "quota":
        handleQuota(msg);
        break;
      case "event":
        handleEvent(msg.event);
        break;
      case "usageDaily":
        handleUsageDaily(msg);
        break;
      case "status":
        handleStatus(msg);
        break;
      case "external":
        handleExternal(msg);
        break;
      case "session":
        handleSessionSwitch(msg);
        break;
      default:
        break;
    }
  }
  function safeDispatch(msg) {
    try {
      dispatch(msg);
    } catch (error) {
      console.error("[Kimi Status] \u63A8\u9001\u6D88\u606F\u5904\u7406\u5931\u8D25", msg?.type, error);
      try {
        globalThis.__kcmDebug = {
          ...globalThis.__kcmDebug,
          dispatchError: `${msg?.type}: ${error?.message || error}`
        };
      } catch (e) {
      }
    }
  }
  var bridgeReady = false;
  var pendingMessages = [];
  function installBridge() {
    globalThis.__kcm = {
      push: (msg) => {
        if (!bridgeReady) {
          pendingMessages.push(msg);
          return;
        }
        safeDispatch(msg);
      }
    };
  }
  function markBridgeReady() {
    if (bridgeReady) return;
    bridgeReady = true;
    while (pendingMessages.length) safeDispatch(pendingMessages.shift());
  }
  var disconnectedSince = 0;
  function tickStatusSentence() {
    const d = globalThis.__kcmDebug || {};
    const wsState = String(d.wsState || "");
    const disconnected = d.kapKnown === false || wsState.startsWith("closed") || wsState === "\u7B49kap\u6E90";
    if (disconnected && !disconnectedSince) disconnectedSince = Date.now();
    if (!disconnected) disconnectedSince = 0;
    const level = summarizeStatus({
      dispatchError: d.dispatchError,
      connected: panel.cliUsageConnected,
      usageDailyOk: d.usageDailyOk,
      hasAccum: hasAccumulated(),
      fileState: d.fileState,
      kapKnown: d.kapKnown,
      wsState: d.wsState,
      connectingMs: disconnectedSince ? Date.now() - disconnectedSince : 0
    });
    panel.statusLevel = level;
    const sentence = document.getElementById("ksb-status-sentence");
    if (sentence && level !== "ok") sentence.textContent = t(STATUS_LONG[level]);
  }
  function installStatusTicker() {
    tickStatusSentence();
    setInterval(tickStatusSentence, 1e3);
  }

  // src/panel-app/direct.js
  var kapOrigin = () => globalThis.__kcmKapOrigin || spaOrigin() || learnKapOrigin() || "";
  function spaOrigin() {
    try {
      const value = sessionStorage.getItem("kimi-desktop-server-origin");
      return /^https?:\/\/127\.0\.0\.1:\d+$/.test(value || "") ? value : "";
    } catch (error) {
      return "";
    }
  }
  function learnKapOrigin() {
    try {
      for (const e of performance.getEntriesByType("resource")) {
        const m = /^(https?:\/\/127\.0\.0\.1:\d+)\/api\//.exec(e.name);
        if (m) return m[1];
      }
    } catch (error) {
    }
    return "";
  }
  var ACTIVITY_TTL_MS = 2e4;
  var STATUS_TICK_MS = 2e3;
  var QUOTA_INTERVAL_MS = 6e4;
  var FOCUS_POLL_MS = 1e3;
  var DAILY_TICK_MS = 2e4;
  var EVIDENCE_TYPES = /* @__PURE__ */ new Set([
    "turn.started",
    "turn.step.started",
    "turn.step.completed",
    "thinking.delta",
    "assistant.delta",
    "tool.progress",
    "tool.call.started",
    "tool.result"
  ]);
  function startDirectMode() {
    const push = (msg) => {
      try {
        globalThis.__kcm?.push(msg);
      } catch (error) {
      }
    };
    function debug(state) {
      try {
        globalThis.__kcmDebug = { ...globalThis.__kcmDebug, ...state };
      } catch (error) {
      }
    }
    debug({ kapOrigin: kapOrigin() || "\u672A\u77E5", focusedSid: "", wsState: "init" });
    const apiUrl = (path) => `${kapOrigin()}${path}`;
    async function pollQuota() {
      try {
        const r = await fetch(apiUrl("/api/v1/oauth/usage"));
        const body = await r.json();
        const usages = body?.data?.quota?.usages;
        if (usages) push({ v: 1, type: "quota", quota: usages });
      } catch (error) {
      }
    }
    pollQuota();
    setInterval(pollQuota, QUOTA_INTERVAL_MS);
    let focusedSid = "";
    let lastActiveAt = 0;
    let lastStatus = "";
    let ws = null;
    let retry = 0;
    function currentSidFromLocation() {
      return location.pathname.match(/\/sessions\/([^/?#]+)/)?.[1] || "";
    }
    async function applyFocus(sid) {
      focusedSid = sid;
      debug({ focusedSid: sid, kapOrigin: kapOrigin() || "\u672A\u77E5" });
      let snapshot;
      try {
        const r = await fetch(apiUrl(`/api/v1/sessions/${sid}`));
        const body = await r.json();
        if (body?.data?.usage) snapshot = { usage: body.data.usage };
      } catch (error) {
      }
      push({ v: 1, type: "session", sid, snapshot });
    }
    function pollFocus() {
      const sid = currentSidFromLocation();
      if (sid && sid !== focusedSid) {
        applyFocus(sid);
        wsSubscribe([sid]);
      }
    }
    pollFocus();
    setInterval(pollFocus, FOCUS_POLL_MS);
    setTimeout(refreshDailyChart, 3e3);
    setInterval(refreshDailyChart, DAILY_TICK_MS);
    function noteActivity() {
      lastActiveAt = Date.now();
      setStatus("working");
    }
    function setStatus(status) {
      if (status === lastStatus) return;
      lastStatus = status;
      push({ v: 1, type: "status", status, sessionId: focusedSid });
    }
    setInterval(() => {
      if (lastStatus === "working" && Date.now() - lastActiveAt > ACTIVITY_TTL_MS) {
        setStatus("idle");
      }
    }, STATUS_TICK_MS);
    function wsSubscribe(ids) {
      if (!ids.length || !ws || ws.readyState !== 1) return;
      ws.send(JSON.stringify({ type: "subscribe", id: `s${Date.now()}`, payload: { session_ids: ids } }));
    }
    function connect() {
      const base = kapOrigin();
      if (!base) {
        debug({ wsState: "\u7B49kap\u6E90", kapOrigin: "\u672A\u77E5" });
        setTimeout(connect, 5e3);
        return;
      }
      const url = `${base.replace(/^http/, "ws")}/api/v1/ws?client_id=kcm-injected`;
      try {
        ws = new WebSocket(url);
      } catch (error) {
        scheduleReconnect();
        return;
      }
      debug({ wsState: "connecting", wsUrl: base });
      ws.onopen = () => debug({ wsState: "open" });
      ws.onmessage = (ev) => {
        let m;
        try {
          m = JSON.parse(ev.data);
        } catch (error) {
          return;
        }
        handleServer(m);
      };
      ws.onclose = () => {
        ws = null;
        debug({ wsState: `closed(r${retry})` });
        scheduleReconnect();
      };
      ws.onerror = () => {
        try {
          ws?.close();
        } catch (error) {
        }
      };
    }
    function scheduleReconnect() {
      const delay = Math.min(3e4, 1e3 * 2 ** retry);
      retry += 1;
      setTimeout(connect, delay);
    }
    function handleServer(m) {
      if (m.type === "server_hello") {
        retry = 0;
        ws?.send(JSON.stringify({
          type: "client_hello",
          id: "h1",
          payload: {
            client_id: "kcm-injected",
            subscriptions: focusedSid ? [focusedSid] : [],
            cursors: {}
          }
        }));
        return;
      }
      if (m.type === "ping") {
        ws?.send(JSON.stringify({ type: "pong", payload: { nonce: m.payload?.nonce } }));
        return;
      }
      if (m.type === "ack") {
        const resync = m.payload?.resync_required || [];
        if (resync.length) wsSubscribe(resync);
        return;
      }
      if (EVIDENCE_TYPES.has(m.type) || m.type === "agent.status.updated" && m.payload?.phase) {
        noteActivity();
      }
      push({ v: 1, type: "event", event: m });
    }
    connect();
  }

  // src/content/widget-structure.js
  var MINI_STORAGE_KEY = "kimi-statusbar.mini";
  var CONFIG_STORAGE_KEY = "kimi-statusbar.config";
  var MODULE_LABELS = {
    header: "\u6807\u9898\u884C",
    input: "\u8F93\u5165",
    cache: "\u7F13\u5B58\u547D\u4E2D",
    output: "\u8F93\u51FA",
    speed: "\u901F\u5EA6",
    duration: "\u4E0A\u8F6E\u8017\u65F6",
    quota5h: "5h \u989D\u5EA6",
    quotaWeek: "\u672C\u5468\u989D\u5EA6",
    usageChart: "\u6D88\u8017\u91CF",
    pet: "\u5BA0\u7269",
    agents: "\u5B50\u4EE3\u7406",
    external: "\u5916\u90E8\u8D26\u6237"
    // quotaMonth: '本月额度' —— 暂时下线，见 metrics.js WIDGET_MODULE_IDS 注释
  };
  var editing = false;
  var menuModuleId = null;
  var longPressStart = null;
  var longPressTimer = null;
  var dragState = null;
  var suppressExitClick = false;
  var deps2 = {
    isDisposed: () => false,
    manualRefresh: () => {
    },
    beginOAuth: () => {
    },
    fetchQuota: () => {
    },
    fetchExternalProviders: () => {
    },
    // 独立面板（panel-app）没有「连接本地 CLI」的目录授权动作：
    // 锁位改为状态句（bridge 的 ticker 按 status-copy 等级更新）并禁用点击
    cliLockAccumulate: false
  };
  function initWidgetStructure(nextDeps) {
    deps2 = { ...deps2, ...nextDeps };
  }
  function quotaModuleHTML(prefix, label) {
    return `
    <div class="ksb-quota-group">
      <div class="ksb-quota-head">
        <span class="ksb-quota-label">${label}</span>
        <span class="ksb-reset" id="ksb-${prefix}-reset"><span class="ksb-reset-full"></span><span class="ksb-reset-short"></span></span>
        <span class="ksb-quota-pct" id="ksb-${prefix}-pct">--</span>
      </div>
      <div class="ksb-progress" id="ksb-${prefix}-progress"><div class="ksb-progress-fill ksb-low" id="ksb-${prefix}-fill" style="width:0%"></div><span class="ksb-pace" id="ksb-${prefix}-pace" hidden></span></div>
    </div>`;
  }
  var MODULE_HTML = {
    input: () => `
    <div class="ksb-stat">
      <span class="ksb-stat-label">${t("\u8F93\u5165")}</span>
      <span class="ksb-stat-value" id="ksb-input-tokens">0</span>
    </div>
    <svg class="ksb-spark ksb-spark-input" id="ksb-input-spark" viewBox="0 0 100 28" preserveAspectRatio="none"></svg>`,
    cache: () => `
    <div class="ksb-stat">
      <span class="ksb-stat-label">${t("\u7F13\u5B58\u547D\u4E2D")}</span>
      <span class="ksb-stat-value" id="ksb-cache-pct">--</span>
    </div>
    <svg class="ksb-spark ksb-spark-cache" id="ksb-cache-spark" viewBox="0 0 100 28" preserveAspectRatio="none"></svg>`,
    output: () => `
    <div class="ksb-stat">
      <span class="ksb-stat-label">${t("\u8F93\u51FA")}</span>
      <span class="ksb-stat-value" id="ksb-output-tokens">0</span>
    </div>
    <svg class="ksb-spark ksb-spark-output" id="ksb-output-spark" viewBox="0 0 100 28" preserveAspectRatio="none"></svg>`,
    speed: () => `
    <div class="ksb-stat">
      <span class="ksb-stat-label">${t("\u901F\u5EA6")}<span class="ksb-stat-sub" id="ksb-duration-sub" hidden><span class="ksb-duration-word">${t("\u4E0A\u8F6E")}</span><span id="ksb-duration-val"></span></span></span>
      <span class="ksb-stat-value" id="ksb-speed-val">--</span>
    </div>
    <svg class="ksb-spark ksb-spark-speed" id="ksb-speed-spark" viewBox="0 0 100 28" preserveAspectRatio="none"></svg>`,
    duration: () => `
    <div class="ksb-stat">
      <span class="ksb-stat-label">${t("\u4E0A\u8F6E\u8017\u65F6")}</span>
      <span class="ksb-stat-value" id="ksb-duration-value">--</span>
    </div>
    <svg class="ksb-spark ksb-spark-duration" id="ksb-duration-spark" viewBox="0 0 100 28" preserveAspectRatio="none"></svg>`,
    quota5h: () => quotaModuleHTML("5h", "5h"),
    quotaWeek: () => quotaModuleHTML("week", t("\u672C\u5468")),
    // quotaMonth: quotaModuleHTML('month', '本月'), —— 暂时下线，见 metrics.js 注释
    pet: () => `
    <div class="ksb-pet">
      <div class="ksb-pet-clip"><canvas class="ksb-pet-canvas" id="ksb-pet-canvas" width="112" height="112"></canvas></div>
      <div class="ksb-pet-stats">
        <div class="ksb-pet-total-row">
          <span class="ksb-quota-label" id="ksb-pet-label">${t("\u4ECA\u65E5\u6D88\u8017")}</span>
          <span class="ksb-pet-total" id="ksb-pet-total">--</span>
        </div>
        <span class="ksb-pet-status" id="ksb-pet-status" data-status="idle"><span id="ksb-pet-status-text">${t("\u7A7A\u95F2")}</span><span class="ksb-pet-clock" id="ksb-pet-clock" hidden><span id="ksb-pet-clock-num"></span><span id="ksb-pet-ampm"></span></span></span>
      </div>
    </div>`,
    usageChart: () => `
    <div class="ksb-chart">
      <div class="ksb-chart-head">
        <span class="ksb-quota-label" id="ksb-chart-label">${t("\u672C\u5468\u6D88\u8017")}</span>
        <span class="ksb-chart-hit"><span class="ksb-chart-hit-full" id="ksb-chart-hit-full"></span><span class="ksb-chart-hit-short" id="ksb-chart-hit-short"></span></span>
      </div>
      <span class="ksb-chart-total" id="ksb-chart-total">--</span>
      <div class="ksb-chart-bars" id="ksb-chart-bars"></div>
    </div>
    ${deps2.cliLockAccumulate ? `<button type="button" class="ksb-cli-lock" id="ksb-cli-lock" disabled>
      <span id="ksb-status-sentence">${t("\u6B63\u5728\u52A0\u8F7D\u6570\u636E\u7EDF\u8BA1\u2026")}</span><small id="kcm-data-status"></small>
    </button>` : `<button type="button" class="ksb-cli-lock" id="ksb-cli-lock">
      <span>${t("\u8FDE\u63A5\u672C\u5730 CLI")}</span><small>${t("\u5F00\u542F24h\u30017d\u300130d\u7EDF\u8BA1")}</small>
    </button>`}`,
    agents: () => `
    <div class="ksb-agents">
      <div class="ksb-agents-head">
        <span class="ksb-quota-label">${t("\u4EE3\u7406")}</span>
        <span class="ksb-agent-metric m-in">${t("\u8F93\u5165")}</span>
        <span class="ksb-agent-metric m-out">${t("\u8F93\u51FA")}</span>
        <span class="ksb-agent-metric m-hit">${t("\u547D\u4E2D")}</span>
      </div>
      <div class="ksb-agents-list" id="ksb-agents-list"></div>
    </div>`,
    external: () => `
    <div class="ksb-stat ksb-external-stat">
      <span class="ksb-stat-label"><span id="ksb-external-title">${t("\u5916\u90E8\u8D26\u6237")}</span><span class="ksb-stat-sub" id="ksb-external-sub" hidden></span></span>
      <span class="ksb-stat-value" id="ksb-external-value">--</span>
    </div>
    <div class="ksb-agents ksb-external-full">
      <div class="ksb-agents-head">
        <span class="ksb-quota-label">${t("\u5916\u90E8\u8D26\u6237")}</span>
      </div>
      <div class="ksb-external-list" id="ksb-external-list"></div>
    </div>`
  };
  function headerModuleHTML() {
    const toConsole = panel.widgetConfig.modules.header.balanceLink === "console";
    return `
    <div class="ksb-header">
      <span class="ksb-status-dot ksb-idle" id="ksb-status-dot"></span>
      <span class="ksb-title" title="${t("\u70B9\u51FB\u91CD\u7F6E\u5E76\u91CD\u65B0\u62C9\u53D6\u6570\u636E")}"><span class="ksb-title-long">Kimi Code</span><span class="ksb-title-brief">Kimi</span></span>
      <span class="ksb-agent-status" id="ksb-agent-status">${t("\u7A7A\u95F2")}</span>
      ${panel.widgetConfig.modules.header.showBalance ? `<span class="ksb-balance" id="ksb-balance" title="${toConsole ? t("\u6253\u5F00 Kimi Code \u63A7\u5236\u53F0") : t("\u67E5\u770B / \u5145\u503C\u989D\u5EA6")}">${t("\u4F59\u989D --")}</span>` : ""}
    </div>`;
  }
  function buildModule(id) {
    const module = document.createElement("div");
    module.className = "ksb-module" + (panel.widgetConfig.modules[id]?.span === 2 ? " ksb-span-2" : "");
    module.dataset.module = id;
    module.innerHTML = `${id === "header" ? headerModuleHTML() : MODULE_HTML[id]()}<span class="ksb-module-badge" title="${t("\u6A21\u5757\u8BBE\u7F6E")}">\u2261</span>`;
    module.querySelector(".ksb-module-badge").addEventListener("click", (event) => {
      event.stopPropagation();
      if (editing) openModuleMenu(id);
    });
    module.addEventListener("pointerdown", (event) => beginModuleDrag(event, module));
    if (id === "header") {
      const toConsole = panel.widgetConfig.modules.header.balanceLink === "console";
      module.querySelector(".ksb-title").addEventListener("click", (event) => {
        event.stopPropagation();
        if (!editing) deps2.manualRefresh();
      });
      module.querySelector(".ksb-balance")?.addEventListener("click", (event) => {
        event.stopPropagation();
        if (editing) return;
        window.open(toConsole ? CONSOLE_URL : SUBSCRIPTION_URL, "_blank");
      });
    }
    if (id === "usageChart") {
      module.querySelector(".ksb-cli-lock")?.addEventListener("click", (event) => {
        event.stopPropagation();
        if (editing || deps2.cliLockAccumulate) return;
        chrome.runtime.sendMessage({ type: "cli.usage.open_settings" }).catch(() => {
        });
      });
    }
    return module;
  }
  function zoneLabel(text) {
    const label = document.createElement("span");
    label.className = "ksb-zone-label";
    label.textContent = text;
    return label;
  }
  function renderRegions(widget) {
    const full = widget.querySelector(".ksb-region-full");
    const mini = widget.querySelector(".ksb-region-mini");
    full.replaceChildren();
    mini.replaceChildren();
    widget.querySelector(".ksb-region-hidden")?.remove();
    if (editing) {
      const tray = document.createElement("div");
      tray.className = "ksb-region ksb-region-hidden";
      tray.append(zoneLabel(t("\u9690\u85CF\u533A \xB7 \u62D6\u5230\u4E0B\u65B9\u542F\u7528")));
      for (const id of panel.widgetConfig.orderHidden) tray.append(buildModule(id));
      widget.insertBefore(tray, full);
      full.append(zoneLabel(t("\u5C55\u5F00\u533A \xB7 \u5C55\u5F00\u65F6\u663E\u793A")));
      mini.append(zoneLabel(t("\u56FA\u5B9A\u533A \xB7 \u59CB\u7EC8\u663E\u793A")));
    }
    for (const id of panel.widgetConfig.orderFull) full.append(buildModule(id));
    for (const id of panel.widgetConfig.orderMini) mini.append(buildModule(id));
  }
  function renderWidgetStructure() {
    const widget = document.getElementById("ksb-widget");
    if (!widget) return;
    renderRegions(widget);
    cacheElements();
    applyModeClasses();
    applySidebarTidy();
    renderAll();
    updateBalance(panel.lastWallet);
    for (const prefix of ["5h", "week", "month"]) {
      if (panel.lastQuotaPct[prefix] != null) updateProgress(prefix, panel.lastQuotaPct[prefix]);
      updateResetText(prefix, panel.quotaResetAt[prefix]);
    }
    renderChart();
    renderPetStats();
    petStart();
  }
  function applyWidgetConfig(next, { persist = false } = {}) {
    panel.widgetConfig = normalizeWidgetConfig(next);
    renderWidgetStructure();
    if (quotaPollingWanted()) deps2.fetchQuota();
    if (panel.widgetConfig.modules.external?.show !== "hidden") deps2.fetchExternalProviders();
    if (persist) {
      try {
        chrome.storage.local.set({ [CONFIG_STORAGE_KEY]: panel.widgetConfig }).catch(() => {
        });
      } catch (error) {
      }
    }
  }
  async function loadWidgetConfig() {
    if (deps2.isDisposed()) return;
    try {
      const stored = await chrome.storage.local.get(CONFIG_STORAGE_KEY);
      applyWidgetConfig(stored[CONFIG_STORAGE_KEY]);
    } catch (error) {
      console.warn("[Kimi Status] \u8BFB\u53D6\u9762\u677F\u914D\u7F6E\u5931\u8D25", error);
    }
  }
  function createWidget() {
    const widget = document.createElement("div");
    widget.id = "ksb-widget";
    widget.setAttribute("role", "status");
    widget.addEventListener("click", handleWidgetClick);
    widget.addEventListener("keydown", (event) => {
      if (panel.quotaAuthRequired && (event.key === "Enter" || event.key === " ")) {
        event.preventDefault();
        deps2.beginOAuth();
      }
    });
    widget.innerHTML = `
    <div class="ksb-auth-banner" id="ksb-auth-banner" hidden><span class="ksb-auth-banner-text" id="ksb-auth-banner-text">\u70B9\u51FB\u5B8C\u6210 Kimi \u6388\u6743</span><small>\u6388\u6743\u540E\u663E\u793A\u989D\u5EA6\u4E0E\u9884\u8B66</small></div>
    <div class="ksb-region ksb-region-full"></div>
    <div class="ksb-region ksb-region-mini"></div>
    <div class="ksb-edit-menu" id="ksb-edit-menu" hidden></div>
  `;
    widget.querySelector(".ksb-region-mini").addEventListener("click", (event) => {
      event.stopPropagation();
      if (editing || panel.quotaAuthRequired) return;
      toggleMini();
      if (panel.widgetConfig.orderMini.includes("pet")) petHandleToggle();
    });
    widget.querySelector("#ksb-edit-menu").addEventListener("click", (event) => {
      event.stopPropagation();
      const opt = event.target.closest(".ksb-menu-opt");
      if (opt && menuModuleId) applyMenuOption(menuModuleId, opt.dataset.kind, opt.dataset.value);
    });
    widget.addEventListener("pointerdown", handleLongPressStart);
    widget.addEventListener("pointerup", cancelLongPress);
    widget.addEventListener("pointercancel", cancelLongPress);
    widget.addEventListener("pointermove", (event) => {
      if (longPressStart && Math.hypot(event.clientX - longPressStart.x, event.clientY - longPressStart.y) > 8) cancelLongPress();
    });
    return widget;
  }
  function handleWidgetClick(event) {
    if (suppressExitClick) {
      suppressExitClick = false;
      return;
    }
    if (panel.quotaAuthRequired) {
      deps2.beginOAuth();
      return;
    }
    if (editing && !event.target.closest(".ksb-module") && !event.target.closest(".ksb-edit-menu")) {
      exitEditMode();
    }
  }
  function cacheElements() {
    const byId = (id) => document.getElementById(id);
    const widget = byId("ksb-widget");
    panel.els = {
      widget,
      statusDot: byId("ksb-status-dot"),
      balance: byId("ksb-balance"),
      authBanner: byId("ksb-auth-banner"),
      authBannerText: byId("ksb-auth-banner-text"),
      regionFull: widget?.querySelector(".ksb-region-full"),
      regionMini: widget?.querySelector(".ksb-region-mini"),
      editMenu: byId("ksb-edit-menu"),
      inputTokens: byId("ksb-input-tokens"),
      outputTokens: byId("ksb-output-tokens"),
      cachePct: byId("ksb-cache-pct"),
      speedVal: byId("ksb-speed-val"),
      durationSub: byId("ksb-duration-sub"),
      durationVal: byId("ksb-duration-val"),
      durationValue: byId("ksb-duration-value"),
      agentStatus: byId("ksb-agent-status"),
      chartLabel: byId("ksb-chart-label"),
      chartTotal: byId("ksb-chart-total"),
      chartHitFull: byId("ksb-chart-hit-full"),
      chartHitShort: byId("ksb-chart-hit-short"),
      chartBars: byId("ksb-chart-bars"),
      agentsList: byId("ksb-agents-list"),
      externalList: byId("ksb-external-list"),
      externalTitle: byId("ksb-external-title"),
      externalValue: byId("ksb-external-value"),
      externalSub: byId("ksb-external-sub"),
      cliLock: byId("ksb-cli-lock"),
      petCanvas: byId("ksb-pet-canvas"),
      petStatus: byId("ksb-pet-status"),
      petStatusText: byId("ksb-pet-status-text"),
      petClock: byId("ksb-pet-clock"),
      petClockNum: byId("ksb-pet-clock-num"),
      petAmpm: byId("ksb-pet-ampm"),
      petLabel: byId("ksb-pet-label"),
      petTotal: byId("ksb-pet-total"),
      sparks: {
        input: byId("ksb-input-spark"),
        output: byId("ksb-output-spark"),
        cache: byId("ksb-cache-spark"),
        speed: byId("ksb-speed-spark"),
        duration: byId("ksb-duration-spark")
      },
      quota: {
        "5h": { fill: byId("ksb-5h-fill"), pace: byId("ksb-5h-pace"), pct: byId("ksb-5h-pct"), reset: byId("ksb-5h-reset") },
        week: { fill: byId("ksb-week-fill"), pace: byId("ksb-week-pace"), pct: byId("ksb-week-pct"), reset: byId("ksb-week-reset") },
        month: { fill: byId("ksb-month-fill"), pace: byId("ksb-month-pace"), pct: byId("ksb-month-pct"), reset: byId("ksb-month-reset") }
      }
    };
  }
  function mountWidget(hostEl) {
    if (!hostEl) return false;
    let widget = document.getElementById("ksb-widget");
    if (!widget) {
      widget = createWidget();
      hostEl.appendChild(widget);
    } else if (widget.parentElement !== hostEl) {
      hostEl.appendChild(widget);
    }
    renderWidgetStructure();
    sparkResizeObserver.observe(widget);
    return true;
  }
  function setConnectionHint(text) {
    if (panel.els?.widget) panel.els.widget.title = text || "";
  }
  function readMiniMode() {
    try {
      return localStorage.getItem(MINI_STORAGE_KEY) === "1";
    } catch (error) {
      return false;
    }
  }
  function applyModeClasses() {
    const widget = panel.els?.widget;
    if (!widget) return;
    const miniAvailable = panel.widgetConfig.orderMini.length > 0;
    widget.classList.toggle("ksb-mini", miniAvailable && readMiniMode());
    petSyncRendering();
  }
  function applySidebarTidy() {
    const pet = panel.widgetConfig.modules.pet;
    const tidy = !panel.standaloneMode && pet?.sidebarTidy !== false && pet?.show !== "hidden" && sidebarHeaderTidySafe();
    document.documentElement.classList.toggle("ksb-sidebar-tidy", tidy);
  }
  function sidebarHeaderTidySafe() {
    const header = document.querySelector("aside.side .ch");
    if (!header) return true;
    const allowed = /* @__PURE__ */ new Set();
    for (const selector of [".ch-brand", ".ch-collapse"]) {
      const el = header.querySelector(selector);
      if (!el) continue;
      for (let node = el; node && node !== header; node = node.parentElement) allowed.add(node);
      el.querySelectorAll("*").forEach((node) => allowed.add(node));
    }
    return ![...header.querySelectorAll("*")].some(
      (el) => !allowed.has(el) && el.getClientRects().length > 0
    );
  }
  function toggleMini() {
    const widget = panel.els?.widget;
    if (!widget || panel.widgetConfig.orderMini.length === 0) return;
    const mini = !widget.classList.contains("ksb-mini");
    try {
      localStorage.setItem(MINI_STORAGE_KEY, mini ? "1" : "0");
    } catch (error) {
    }
    applyModeClasses();
    setConnectionHint(mini ? t("Mini \u6A21\u5F0F\uFF1A\u70B9\u51FB\u4E0B\u65B9\u533A\u57DF\u5C55\u5F00") : t("Kimi Status \u5DF2\u8FDE\u63A5"));
  }
  function handleLongPressStart(event) {
    if (editing || panel.quotaAuthRequired || event.button !== 0) return;
    if (event.target.closest(".ksb-edit-menu")) return;
    cancelLongPress();
    longPressStart = { x: event.clientX, y: event.clientY };
    longPressTimer = setTimeout(() => {
      longPressTimer = null;
      longPressStart = null;
      suppressExitClick = true;
      enterEditMode();
    }, 500);
  }
  function cancelLongPress() {
    if (longPressTimer) clearTimeout(longPressTimer);
    longPressTimer = null;
    longPressStart = null;
  }
  function enterEditMode() {
    if (!panel.els?.widget) return;
    editing = true;
    const widget = panel.els.widget;
    widget.classList.add("ksb-editing");
    renderWidgetStructure();
    setTimeout(() => {
      try {
        widget.scrollIntoView({ block: "nearest" });
      } catch {
      }
    }, 0);
    setConnectionHint(t("\u7F16\u8F91\u6A21\u5F0F\uFF1A\u62D6\u62FD\u6A21\u5757\u6392\u5E8F\uFF0C\u70B9 \u2261 \u914D\u7F6E\uFF0CEsc \u6216\u70B9\u7A7A\u767D\u5904\u5B8C\u6210"));
    document.addEventListener("pointerdown", handleOutsidePointerDown, true);
    document.addEventListener("keydown", handleEditKeydown);
  }
  function exitEditMode() {
    editing = false;
    suppressExitClick = false;
    clearDrag();
    menuModuleId = null;
    hideModuleMenu();
    panel.els?.widget?.classList.remove("ksb-editing");
    renderWidgetStructure();
    setConnectionHint("");
    document.removeEventListener("pointerdown", handleOutsidePointerDown, true);
    document.removeEventListener("keydown", handleEditKeydown);
  }
  function handleOutsidePointerDown(event) {
    if (!panel.els?.widget?.contains(event.target)) exitEditMode();
  }
  function handleEditKeydown(event) {
    if (event.key === "Escape") exitEditMode();
  }
  function menuOpts(kind, options, current) {
    const opts = options.map(([value, label]) => `<span class="ksb-menu-opt ${String(current) === String(value) ? "ksb-on" : ""}" data-kind="${kind}" data-value="${value}">${label}</span>`).join("");
    return `<div class="ksb-menu-opts">${opts}</div>`;
  }
  function moduleMenuHTML(id) {
    if (id === "header") {
      const header = panel.widgetConfig.modules.header;
      return `
      <div class="ksb-menu-label">${t("\u6807\u9898\u884C")} \xB7 ${t("\u4F59\u989D")}</div>
      ${menuOpts("showBalance", [[true, t("\u663E\u793A")], [false, t("\u9690\u85CF")]], header.showBalance)}
      <div class="ksb-menu-label">${t("\u4F59\u989D\u70B9\u51FB\u8DF3\u8F6C")}</div>
      ${menuOpts("balanceLink", [["subscription", t("\u5145\u503C\u9875")], ["console", t("\u63A7\u5236\u53F0")]], header.balanceLink)}
    `;
    }
    const mod = panel.widgetConfig.modules[id];
    const widthRow = id === "agents" ? "" : `<div class="ksb-menu-label">${t(MODULE_LABELS[id])} \xB7 ${t("\u5BBD\u5EA6")}</div>
    ${menuOpts("span", [[1, t("\u534A\u5BBD")], [2, t("\u6574\u5BBD")]], mod.span)}`;
    const agentsRow = id === "agents" ? `<div class="ksb-menu-label">${t("\u663E\u793A\u4EE3\u7406")}</div>${agentVisibilityOpts()}` : "";
    const externalRow = id === "external" ? `<div class="ksb-menu-label">${t("\u663E\u793A\u8D26\u6237")}</div>${externalVisibilityOpts()}` : "";
    const rangeRow = id === "usageChart" ? `<div class="ksb-menu-label">${t("\u7EDF\u8BA1\u8303\u56F4")}</div>${menuOpts("chartRange", [["day", "24h"], ["week", "7d"], ["month", "30d"]], mod.chartRange)}` : "";
    const paceRow = id.startsWith("quota") ? `<div class="ksb-menu-label">${t("\u5300\u901F\u53C2\u7167\u7EBF")}</div>${menuOpts("pace", [[true, t("\u663E\u793A")], [false, t("\u9690\u85CF")]], mod.pace)}
      <div class="ksb-menu-label">${t("\u91CD\u7F6E\u65F6\u95F4\u663E\u793A")}</div>${menuOpts("resetFormat", [["countdown", t("\u5012\u8BA1\u65F6")], ["absolute", t("\u5177\u4F53\u65F6\u95F4")]], mod.resetFormat || "countdown")}` : "";
    const statRow = id === "pet" ? `<div class="ksb-menu-label">${t("\u53F3\u4FA7\u6570\u636E")}</div>${menuOpts("stat", [["daily", t("\u4ECA\u65E5\u6D88\u8017")], ["input", t("\u8F93\u5165")], ["output", t("\u8F93\u51FA")], ["cache", t("\u7F13\u5B58\u547D\u4E2D")], ["speed", t("\u901F\u5EA6")], ["balance", t("\u4F59\u989D")]], mod.stat)}
      <div class="ksb-menu-label">${t("\u70B9\u51FB\u5C0F\u7403\u8DF3\u8F6C")}</div>${menuOpts("ballLink", [["none", t("\u65E0\u8DF3\u8F6C")], ["console", t("\u63A7\u5236\u53F0")], ["subscription", t("\u5145\u503C\u9875")]], mod.ballLink || "none")}
      <div class="ksb-menu-label">${t("\u4FA7\u680F\u6539\u9020\uFF08\u53BB logo \u4E0A\u79FB\uFF09")}</div>${menuOpts("sidebarTidy", [[true, t("\u5F00\u542F")], [false, t("\u5173\u95ED")]], mod.sidebarTidy !== false)}` : "";
    return `
    ${widthRow}
    ${agentsRow}
    ${externalRow}
    ${statRow}
    ${paceRow}
    ${rangeRow}
  `;
  }
  function externalVisibilityOpts() {
    const hidden = panel.widgetConfig.modules.external?.hiddenAccounts || [];
    if (!panel.externalProviders.length) {
      return `<div class="ksb-menu-opts"><span class="ksb-menu-opt">${t("\u6682\u65E0\u5DF2\u914D\u7F6E\u8D26\u6237")}</span></div>`;
    }
    const opts = panel.externalProviders.map((account) => {
      const visible = !hidden.includes(account.id);
      const label = account.keyTail ? `${escapeHtml(account.name)} \xB7 ${escapeHtml(account.keyTail)}` : escapeHtml(account.name);
      return `<span class="ksb-menu-opt ${visible ? "ksb-on" : ""}" data-kind="accountToggle" data-value="${escapeHtml(account.id)}">${label}</span>`;
    }).join("");
    return `<div class="ksb-menu-opts">${opts}</div>`;
  }
  function agentVisibilityOpts() {
    const hidden = panel.widgetConfig.modules.agents?.hiddenAgents || [];
    const opts = panel.sessionAgentOrder.map((agentId) => {
      const visible = !hidden.includes(agentId);
      const model = agentModelLabel(agentId);
      const label = `${agentDisplayName(agentId)}${model ? ` \xB7 ${escapeHtml(model)}` : ""}`;
      return `<span class="ksb-menu-opt ${visible ? "ksb-on" : ""}" data-kind="agentToggle" data-value="${escapeHtml(agentId)}">${label}</span>`;
    }).join("");
    return `<div class="ksb-menu-opts">${opts}</div>`;
  }
  function openModuleMenu(id) {
    menuModuleId = id;
    const menu = panel.els?.editMenu;
    if (!menu) return;
    menu.innerHTML = moduleMenuHTML(id);
    menu.hidden = false;
    const anchor = panel.els.widget.querySelector(`.ksb-module[data-module="${id}"] .ksb-module-badge`);
    if (anchor) {
      const widgetRect = panel.els.widget.getBoundingClientRect();
      const rect = anchor.getBoundingClientRect();
      const belowTop = rect.bottom - widgetRect.top + 4;
      if (belowTop + menu.offsetHeight > widgetRect.height) {
        menu.style.top = `${rect.top - widgetRect.top - menu.offsetHeight - 4}px`;
      } else {
        menu.style.top = `${belowTop}px`;
      }
      menu.style.left = `${Math.max(0, Math.min(rect.left - widgetRect.left, widgetRect.width - menu.offsetWidth - 4))}px`;
    }
  }
  function hideModuleMenu() {
    if (panel.els?.editMenu) panel.els.editMenu.hidden = true;
  }
  function applyMenuOption(id, kind, value) {
    const next = JSON.parse(JSON.stringify(panel.widgetConfig));
    if (kind === "showBalance" || kind === "balanceLink") {
      next.modules.header[kind] = value === "true" ? true : value === "false" ? false : value;
    } else if (kind === "span") {
      next.modules[id].span = Number(value) === 2 ? 2 : 1;
    } else if (kind === "pace") {
      next.modules[id].pace = value === "true";
    } else if (kind === "resetFormat") {
      next.modules[id].resetFormat = value === "absolute" ? "absolute" : "countdown";
    } else if (kind === "stat") {
      next.modules[id].stat = value;
    } else if (kind === "ballLink") {
      next.modules[id].ballLink = value;
    } else if (kind === "sidebarTidy") {
      next.modules[id].sidebarTidy = value === "true";
    } else if (kind === "chartRange") {
      next.modules[id].chartRange = value;
    } else if (kind === "agentToggle") {
      const hidden = Array.isArray(next.modules.agents.hiddenAgents) ? [...next.modules.agents.hiddenAgents] : [];
      const index = hidden.indexOf(value);
      if (index >= 0) hidden.splice(index, 1);
      else hidden.push(value);
      next.modules.agents.hiddenAgents = hidden;
    } else if (kind === "accountToggle") {
      const hidden = Array.isArray(next.modules.external.hiddenAccounts) ? [...next.modules.external.hiddenAccounts] : [];
      const index = hidden.indexOf(value);
      if (index >= 0) hidden.splice(index, 1);
      else hidden.push(value);
      next.modules.external.hiddenAccounts = hidden;
    }
    applyWidgetConfig(next, { persist: true });
    if (kind === "agentToggle" || kind === "accountToggle") {
      openModuleMenu(id);
      return;
    }
    menuModuleId = null;
    hideModuleMenu();
  }
  function beginModuleDrag(event, moduleEl) {
    if (!editing || event.button !== 0) return;
    if (event.target.closest(".ksb-module-badge")) return;
    event.preventDefault();
    const rect = moduleEl.getBoundingClientRect();
    dragState = {
      el: moduleEl,
      // 固定基准：拖动全程相对原始位置位移、不碰 DOM，松手才落位，避免反馈振荡闪烁
      origLeft: rect.left,
      origTop: rect.top,
      grabX: event.clientX - rect.left,
      grabY: event.clientY - rect.top,
      startX: event.clientX,
      startY: event.clientY,
      active: false
    };
    document.addEventListener("pointermove", handleDragMove);
    document.addEventListener("pointerup", handleDragEnd, { once: true });
    document.addEventListener("pointercancel", handleDragEnd, { once: true });
  }
  function regionAtPoint(y) {
    const zones = [
      { key: "hidden", el: panel.els.widget.querySelector(".ksb-region-hidden") },
      { key: "full", el: panel.els.regionFull },
      { key: "mini", el: panel.els.regionMini }
    ].filter((zone) => zone.el);
    return zones.reduce((nearest, zone) => {
      const rect = zone.el.getBoundingClientRect();
      const distance = y < rect.top ? rect.top - y : y > rect.bottom ? y - rect.bottom : 0;
      return !nearest || distance < nearest.distance ? { ...zone, distance } : nearest;
    }, null);
  }
  function handleDragMove(event) {
    if (!dragState) return;
    if (!dragState.active) {
      const moved = Math.hypot(event.clientX - dragState.startX, event.clientY - dragState.startY);
      if (moved < 5) return;
      dragState.active = true;
      dragState.el.classList.add("ksb-dragging");
      hideModuleMenu();
    }
    dragState.el.style.transform = `translate(${event.clientX - dragState.grabX - dragState.origLeft}px, ${event.clientY - dragState.grabY - dragState.origTop}px)`;
    const zone = regionAtPoint(event.clientY)?.key;
    if (zone && zone !== dragState.zone) {
      dragState.zone = zone;
      dragState.el.classList.remove("ksb-drag-to-hidden", "ksb-drag-to-full", "ksb-drag-to-mini");
      dragState.el.classList.add(`ksb-drag-to-${zone}`);
    }
  }
  function placeDraggedModule(x, y) {
    const { el } = dragState;
    const region = regionAtPoint(y)?.el;
    if (!region) return;
    const modules = [...region.children].filter(
      (child) => child !== el && child.classList.contains("ksb-module")
    );
    for (let i = 0; i < modules.length; i++) {
      const child = modules[i];
      const rect = child.getBoundingClientRect();
      if (y < rect.top - 6) {
        region.insertBefore(el, child);
        return;
      }
      if (y > rect.bottom + 6) continue;
      if (x < rect.left + rect.width / 2) {
        region.insertBefore(el, child);
        return;
      }
      const next = modules[i + 1];
      const nextTop = next ? next.getBoundingClientRect().top : Infinity;
      if (nextTop > rect.top + rect.height / 2) {
        const reference = child.nextSibling;
        if (reference !== el) region.insertBefore(el, reference);
        return;
      }
    }
    region.appendChild(el);
  }
  function clearDrag() {
    document.removeEventListener("pointermove", handleDragMove);
    document.removeEventListener("pointerup", handleDragEnd);
    document.removeEventListener("pointercancel", handleDragEnd);
    if (!dragState) return;
    dragState.el.style.transform = "";
    dragState.el.classList.remove("ksb-dragging", "ksb-drag-to-hidden", "ksb-drag-to-full", "ksb-drag-to-mini");
    dragState = null;
  }
  function handleDragEnd(event) {
    if (!dragState) {
      clearDrag();
      return;
    }
    const { active } = dragState;
    if (active && event) placeDraggedModule(event.clientX, event.clientY);
    clearDrag();
    if (active) commitDragOrder();
  }
  function commitDragOrder() {
    const next = JSON.parse(JSON.stringify(panel.widgetConfig));
    const readZone = (selector) => [...panel.els.widget.querySelectorAll(`${selector} .ksb-module`)].map((m) => m.dataset.module);
    next.orderFull = readZone(".ksb-region-full");
    next.orderMini = readZone(".ksb-region-mini");
    next.orderHidden = readZone(".ksb-region-hidden");
    for (const id of next.orderFull) next.modules[id].show = "full";
    for (const id of next.orderMini) next.modules[id].show = "mini";
    for (const id of next.orderHidden) next.modules[id].show = "hidden";
    applyWidgetConfig(next, { persist: true });
  }

  // src/panel-app.js
  panel.standaloneMode = true;
  var PANEL_WIDGET_CONFIG = {
    version: 3,
    modules: {
      header: { show: "hidden", span: 2, showBalance: true, balanceLink: "subscription" },
      input: { show: "full", span: 1 },
      cache: { show: "full", span: 1 },
      output: { show: "full", span: 1 },
      speed: { show: "full", span: 1 },
      duration: { show: "hidden", span: 2 },
      quota5h: { show: "mini", span: 1, pace: true, resetFormat: "countdown" },
      quotaWeek: { show: "mini", span: 1, pace: true, resetFormat: "countdown" },
      usageChart: { show: "hidden", span: 2, chartRange: "week" },
      pet: { show: "mini", span: 2, stat: "daily", sidebarTidy: false, ballLink: "subscription" },
      agents: { show: "hidden", span: 2, hiddenAgents: [] },
      external: { show: "full", span: 2, hiddenAccounts: [] }
    },
    orderFull: ["external", "output", "cache", "input", "speed"],
    orderMini: ["pet", "quota5h", "quotaWeek"],
    orderHidden: ["header", "duration", "agents", "usageChart"]
  };
  initWidgetStructure({
    isDisposed: () => false,
    // 标题行点击：本地数值与折线样本清空重计（额度/统计由 direct.js 轮询与
    // loader 快照在下一周期自动补齐，无需额外请求）
    manualRefresh: () => {
      resetMetrics();
      panel.sessionSamples.length = 0;
      panel.turnDurations.length = 0;
      renderAll();
    },
    // 授权 / 额度 / 外部账户的数据都由直连与 loader 快照提供，这里只留空桩
    // （widget-structure 与扩展共用，注入模式无对应动作）
    beginOAuth: () => {
    },
    fetchQuota: () => {
    },
    fetchExternalProviders: () => {
    },
    // 无「连接本地 CLI」目录授权动作：锁位由 widget-structure 改述为统计积累中
    cliLockAccumulate: true
  });
  initPet({
    isDisposed: () => false,
    getSessionId
  });
  initRender({
    isDisposed: () => false,
    petUpdateStatus,
    // 桌面宠物（roam pet）不启用
    roamPetSetStatus: () => {
    }
  });
  installBridge();
  var host = document.createElement("div");
  host.id = "ksb-panel-host";
  if (typeof globalThis.__kcmMountInto === "function") {
    globalThis.__kcmMountInto(host);
  } else {
    document.body.appendChild(host);
  }
  mountWidget(host);
  try {
    if (localStorage.getItem("kimi-locale")) syncLocaleFromPage();
  } catch (error) {
  }
  async function bootstrap() {
    try {
      const stored = await chrome.storage.local.get(CONFIG_STORAGE_KEY);
      if (stored[CONFIG_STORAGE_KEY] == null) {
        await chrome.storage.local.set({ [CONFIG_STORAGE_KEY]: PANEL_WIDGET_CONFIG }).catch(() => {
        });
      }
      await loadWidgetConfig();
    } catch (error) {
      console.warn("[Kimi Status] \u9762\u677F\u914D\u7F6E\u52A0\u8F7D\u5931\u8D25", error);
      applyWidgetConfig(PANEL_WIDGET_CONFIG);
    }
    markBridgeReady();
    installStatusTicker();
    try {
      startDirectMode();
    } catch (error) {
      console.error("[Kimi Status] \u76F4\u8FDE\u6A21\u5F0F\u542F\u52A8\u5931\u8D25", error);
    }
    window.dispatchEvent(new Event("kcm:panel-ready"));
  }
  bootstrap();
})();
