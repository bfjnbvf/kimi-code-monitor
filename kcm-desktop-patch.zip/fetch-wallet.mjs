#!/usr/bin/env node

// src/panel-app/patch/fetch-wallet.mjs
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { pathToFileURL } from "node:url";
var USAGES_API = "https://api.kimi.com/coding/v1/usages";
function parseArgs(argv) {
  const args = { out: "" };
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--out") args.out = argv[i += 1];
  }
  return args;
}
function balanceYuan(wallet) {
  var _a;
  const status = String((wallet == null ? void 0 : wallet.status) || "").toUpperCase();
  if (status !== "STATUS_ACTIVE" && status !== "STATUS_ENABLED") return 0;
  const amountLeft = Number((_a = wallet == null ? void 0 : wallet.balance) == null ? void 0 : _a.amountLeft);
  return Number.isFinite(amountLeft) ? Math.max(0, amountLeft / 1e8) : null;
}
async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.out) {
    console.error("\u7528\u6CD5: node fetch-wallet.mjs --out <wallet.js\u8DEF\u5F84>");
    process.exit(1);
  }
  const credPath = path.join(os.homedir(), ".kimi-code", "credentials", "kimi-code.json");
  let token = "";
  try {
    token = String(JSON.parse(fs.readFileSync(credPath, "utf8")).access_token || "");
  } catch (error) {
    console.error("[wallet] \u672A\u627E\u5230\u5BA2\u6237\u7AEF\u51ED\u636E\uFF08~/.kimi-code/credentials/kimi-code.json\uFF09\uFF1A\u6253\u5F00\u4E00\u6B21 Kimi Code \u5BA2\u6237\u7AEF\u540E\u91CD\u8BD5");
    process.exit(2);
  }
  if (!token) {
    console.error("[wallet] \u51ED\u636E\u91CC\u6CA1\u6709 access_token\uFF1A\u6253\u5F00\u4E00\u6B21 Kimi Code \u5BA2\u6237\u7AEF\u540E\u91CD\u8BD5");
    process.exit(2);
  }
  let body;
  try {
    const response = await fetch(USAGES_API, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
      signal: AbortSignal.timeout(15e3)
    });
    if (response.status === 401 || response.status === 403) {
      console.error("[wallet] \u51ED\u636E\u5DF2\u5931\u6548\uFF08401/403\uFF09\uFF1A\u6253\u5F00\u4E00\u6B21 Kimi Code \u5BA2\u6237\u7AEF\uFF08\u4F1A\u81EA\u52A8\u7EED\u671F\uFF09\u540E\u91CD\u8BD5");
      process.exit(2);
    }
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    body = await response.json();
  } catch (error) {
    console.error(`[wallet] \u8BF7\u6C42\u5931\u8D25\uFF1A${(error == null ? void 0 : error.message) || error}`);
    process.exit(1);
  }
  const wallet = (body == null ? void 0 : body.booster_wallet) ?? (body == null ? void 0 : body.boosterWallet) ?? null;
  if (!wallet || typeof wallet !== "object") {
    console.error("[wallet] \u54CD\u5E94\u91CC\u6CA1\u6709\u52A0\u6CB9\u5305\u4F59\u989D\u5B57\u6BB5\uFF08\u8D26\u53F7\u53EF\u80FD\u6CA1\u6709\u52A0\u6CB9\u5305\uFF09");
    process.exit(3);
  }
  fs.mkdirSync(path.dirname(args.out), { recursive: true });
  fs.writeFileSync(args.out, `window.__kcmWallet = ${JSON.stringify({ wallet, fetchedAt: (/* @__PURE__ */ new Date()).toISOString() })};
`);
  const yuan = balanceYuan(wallet);
  console.log(`[wallet] \u4F59\u989D\u5FEB\u7167\u5DF2\u5199\u5165 ${args.out}\uFF08\u5269\u4F59 ${yuan == null ? "\u672A\u77E5" : `\xA5${yuan.toFixed(2)}`}\uFF09`);
}
if (process.argv[1] && import.meta.url === pathToFileURL(fs.realpathSync(process.argv[1])).href) {
  await main();
}
